from django.apps import AppConfig


class FeatureConfig(AppConfig):
    name = 'Feature'
