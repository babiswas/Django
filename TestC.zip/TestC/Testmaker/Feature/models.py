from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
from django.urls import reverse

# Create your models here.

class Project(models.Model):
	project_name=models.CharField(max_length=200)
	datecreated=models.DateTimeField(default=datetime.now,blank=False)

	def __str__(self):
		return str(self.project_name)

class Feature(models.Model):
	featurename=models.CharField(max_length=100)
	testcycle=models.CharField(max_length=50)
	featureQA=models.ForeignKey(User,null=True,on_delete=models.SET_NULL)
	dateCreated=models.DateTimeField(default=datetime.now,blank=False)
	project=models.ForeignKey(Project,on_delete=models.CASCADE)

	def __str__(self):
		return str(self.featurename)
	def get_absolute_url(self):
		return reverse('Feature:feature_detail',kwargs={"id":self.id})

class Test(models.Model):
	STATUS_CHOICE=(
		('DEVELOPEMENT','In Developement'),
		('CLOSED','Closed'),	
		('DESIGN','In Design')
		)
	test_summary=models.CharField(max_length=200)
	test_verdict=models.BooleanField(default=False)
	test_status=models.CharField(max_length=30,choices=STATUS_CHOICE)
	feature=models.ForeignKey(Feature,on_delete=models.CASCADE)
	test_writer=models.ForeignKey(User,null=True,on_delete=models.SET_NULL)

	def __str__(self):
		return str(self.test_summary)
	def get_absolute_url(self):
		return reverse('Feature:test_detail',kwargs={"id":self.id})



