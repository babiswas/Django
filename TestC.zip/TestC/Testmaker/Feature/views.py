from django.shortcuts import render, get_object_or_404, redirect
from .forms import ProjectForm, FeatureForm, TestForm
from .models import Project, Feature, Test
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponse
from django.contrib import auth


# Create your views here.


def test_home(request):
    return render(request,'Feature/Test/test_home.html')

def feature_home(request):
    return render(request,'Feature/Feature/feature_home.html')

def home(request):
    return render(request,'Feature/base.html')

def project_home(request):
    return render(request,'Feature/Project/project_home.html')


def create_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return redirect('Feature:project_list', permanent=True)
    form = ProjectForm()
    return render(request, 'Feature/Project/project_form.html',{'form': form})


def add_feature(request):
    if request.method == 'POST':
        form = FeatureForm(request.POST)
        if form.is_valid():
            feature = form.save(commit=False)
            feature.featureQA = request.user
            feature.save()
            return redirect('Feature:feature_list', permanent=True)
    form = FeatureForm()
    return render(request, 'Feature/Feature/feature_form.html', {'form': form})


def add_test(request):
    if request.method == 'POST':
        form = TestForm(request.POST)
        if form.is_valid():
            test = form.save(commit=False)
            test.test_writer = request.user
            test.save()
        return redirect('Feature:test_list',permanent=True)
    form = TestForm()
    return render(request, 'Feature/Test/test_form.html', {'form': form})


def feature_list(request):
    #try:
       features = Feature.objects.all()
       return render(request,'Feature/Feature/feature_list.html',{'features': features})
    #except Exception as e:
       #return redirect('Feature:feature_create',permanent=True)


def project_list(request):
    try:
       projects = Project.objects.all()
       return render(request, 'Feature/Project/project_list.html', {'projects': projects})
    except Exception as e:
       return redirect('Feature:project_create',permanent=True)


def feature_detail(request, id):
    feature = get_object_or_404(Feature, id=id)
    return render(request, 'Feature/Feature/feature_detail.html', {'feature': feature})


def test_list(request):
    try:
        tests = Test.objects.all()
        return render(request, 'Feature/Test/test_list.html', {'tests': tests})
    except Exception as e:
       return redirect('Feature:test_list',permanent=True)

def test_detail(request, id):
    test= get_object_or_404(Test, id=id)
    return render(request, 'Feature/Test/test_detail.html', {'test': test})


def update_test(request, id):
    try:
        test = get_object_or_404(Test,test_writer=request.user, id=id)
        if request.method == 'POST':
            form = TestForm(request.POST, instance=test)
            form.save()
            return redirect('Feature:test_list',permanent=True)
        form = TestForm(instance=test)
        return render(request, 'Feature/Test/test_form.html',{"form": form})
    except Exception as e:
        return HttpResponse('Unauthorized', status=401)


def update_feature(request, id):
    try:
          feature = get_object_or_404(Feature,featureQA=request.user,id=id)
          if request.method == 'POST':
             form = FeatureForm(request.POST,instance=feature)
             newform=form.save(commit=False)
             newform.featureQA=request.user
             newform.save()
             return redirect('Feature:feature_list',permanent=True)
          form = FeatureForm(instance=feature)
          return render(request, 'Feature/Feature/feature_form.html',{"form": form})
    except Exception as e:
          return HttpResponse('Unauthorized',status=401)


def register(request):
    if request.method == 'POST':
        f = UserCreationForm(request.POST)
        if f.is_valid():
            f.save()
            return redirect('Feature:login', permanent=True)
    f=UserCreationForm()
    return render(request, 'Feature/Register/register.html', {'form': f})


def logout(request):
    auth.logout(request)
    return redirect('Feature:login', permanent=True)


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('Feature:project_list', permanent=True)
    return render(request, 'Feature/Register/login.html')
