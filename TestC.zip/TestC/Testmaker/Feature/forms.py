from django import forms
from .models import Project,Feature,Test

class ProjectForm(forms.ModelForm):
	class Meta:
		model=Project
		fields='__all__'



class FeatureForm(forms.ModelForm):
	project=forms.ModelChoiceField(queryset=Project.objects.all())
	class Meta:
		model=Feature
		fields='__all__'
		exclude=['featureQA']


class TestForm(forms.ModelForm):
	project=forms.ModelChoiceField(queryset=Project.objects.all())
	class Meta:
		model=Test
		fields='__all__'
		exclude=['test_writer']