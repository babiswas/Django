from django.contrib import admin
from django.urls import path,include
from . import views

app_name='Feature'
urlpatterns = [
    path('',views.home,name='home'),
    path('register/',views.register,name='register'),
    path('login/',views.login,name ='login'),
    path('logout/',views.logout,name ='logout'),
    #Project
    path('project/',views.project_home,name='project'),
    path('project/project_create/',views.create_project,name ='project_create'),
    path('project/project_list/',views.project_list,name ='project_list'),
    #Feature
    path('feature/',views.feature_home,name='feature'),
    path('feature/feature_create/',views.add_feature,name='feature_create'),
    path('feature/feature_list/',views.feature_list,name='feature_list'),
    path('feature/feature_detail/<int:id>/update/',views.update_feature,name='feature_update'),
    path('feature/feature_detail/<int:id>/',views.feature_detail,name='feature_detail'),
    #Test
    path('test/',views.test_home,name='test'),
    path('test/test_detail/<int:id>/',views.test_detail,name='test_detail'),
    path('test/test_list/',views.test_list,name='test_list'),
    path('test/test_create/',views.add_test,name='test_create'),
    path('test/test_detail/<int:id>/update/',views.update_test,name='test_update'),
]