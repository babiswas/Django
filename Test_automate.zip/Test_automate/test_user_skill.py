from utility import *

@get_request
def get_skill(*args):
    return args[1],args[2]

@Report_generate
def test_skill_include_user_skill(Testcase,userid,user_skill_id,include,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = include
    data["ids"] = str(user_skill_id)
    try:
        str1="users/"+str(userid)+"/userSkills"
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skill_include_user_skill_id(Testcase,userid,user_skill_id,include,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = include
    try:
        str1="users/"+str(userid)+"/userSkills/"+str(user_skill_id)
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


if __name__=="__main__":
    Auto_init("userskill_include.csv")
    Env_init("d2962f50-2fc5-44ff-b121-f1a66fc28bf8", "2de3af33-6fb5-4b3e-9625-49b605996901","239fab80cecf817be675909d46777cc0")
    test_skill_include_user_skill("Verify the objects in include array for include=learnerBadge.badge",7273699,"7273699_44018_2","learnerBadge.badge","7384","7273699_7384_COMPETENCY_44018_2")
    test_skill_include_user_skill("Verify the objects in include array for include=learnerBadge.learner",7273699,"7273699_44018_2","learnerBadge.learner","7273699","7273699_7384_COMPETENCY_44018_2")
    test_skill_include_user_skill("Verify the objects in include array for include=learnerBadge.model",7273699,"7273699_44018_2","learnerBadge.model","44018_2","7273699_7384_COMPETENCY_44018_2")
    test_skill_include_user_skill("Verify the objects in the include array for include=learningObject.enrollment",7273699,"7273699_44018_2","learningObject.enrollment","course:3040248_5702336_7273699","course:3040247_5702335_7273699","course:3040246_5702334_7273699","course:3040248","course:3040247","course:3040246")
    test_skill_include_user_skill("Verify the objects in the include array for include=learningObject.skills",7273699,"7273699_44018_2","learningObject.skills","course:3040246_44018","course:3040247_44018","course:3040248_44018","course:3040246","course:3040247","course:3040248")
    test_skill_include_user_skill("Verify the objects in the include array for include=skillLevel.badge",7273699,"7273699_44018_2","skillLevel.badge","7384","44018_2")
    test_skill_include_user_skill("Verify the objects in the include array for include=skillLevel.skill.levels.badge", 7273699,"7273699_44018_2", "skillLevel.skill.levels.badge","7382","44018","44018_1","44018_2")
    test_skill_include_user_skill("Verify the objects in the include array for include=user,skillLevel.badge",7273699, "7273699_44018_2", "user,skillLevel.badge","7273699","44018_2","7384")

    #########################################  USERSKILL_ID ###########################################################################################
    
    test_skill_include_user_skill_id("Verify the objects in include array for include=learnerBadge.badge",7273699,"7273699_44018_2","learnerBadge.badge","7384","7273699_7384_COMPETENCY_44018_2")
    test_skill_include_user_skill_id("Verify the objects in include array for include=learnerBadge.learner",7273699,"7273699_44018_2","learnerBadge.learner","7273699","7273699_7384_COMPETENCY_44018_2")
    test_skill_include_user_skill_id("Verify the objects in include array for include=learnerBadge.model",7273699,"7273699_44018_2","learnerBadge.model","44018_2","7273699_7384_COMPETENCY_44018_2")
    test_skill_include_user_skill_id("Verify the objects in the include array for include=learningObject.enrollment",7273699,"7273699_44018_2","learningObject.enrollment","course:3040248_5702336_7273699","course:3040247_5702335_7273699","course:3040246_5702334_7273699","course:3040248","course:3040247","course:3040246")
    test_skill_include_user_skill_id("Verify the objects in the include array for include=learningObject.skills",7273699,"7273699_44018_2","learningObject.skills","course:3040246_44018","course:3040247_44018","course:3040248_44018","course:3040246","course:3040247","course:3040248")
    test_skill_include_user_skill_id("Verify the objects in the include array for include=skillLevel.badge",7273699,"7273699_44018_2","skillLevel.badge","7384","44018_2")
    test_skill_include_user_skill_id("Verify the objects in the include array for include=skillLevel.skill.levels.badge", 7273699,"7273699_44018_2", "skillLevel.skill.levels.badge","7382","44018","44018_1","44018_2")
    test_skill_include_user_skill_id("Verify the objects in the include array for include=user,skillLevel.badge",7273699, "7273699_44018_2", "user,skillLevel.badge","7273699","44018_2","7384")
    Auto_close()