from utility import *
from collections import defaultdict


@get_request
def get_lo(*args):
    return args[1]

@Report_generate
def test_course_enrollment_player(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    objects=[]
    try:
        for obj in req["included"]:
            objects.append(obj["id"])
        for i in args:
            if i not in objects:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_enrollment_enrollmentobject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    enrollment=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstanceEnrollment":
                enrollment.append(obj["id"])
        for i in args:
            if i not in enrollment:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_enrollment_resourceObject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    resource=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="resource":
                resource.append(obj["id"])
        for i in args:
            if i not in resource:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_enrollment_loresourceObject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresource=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource":
                loresource.append(obj["id"])
        for i in args:
            if i not in loresource:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_enrollment_loresourcegradeObject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresourcegrade=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResourceGrade":
                loresourcegrade.append(obj["id"])
        for i in args:
            if i not in loresourcegrade:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_enrollment_loinstanceObject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresourcegrade=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                loresourcegrade.append(obj["id"])
        for i in args:
            if i not in loresourcegrade:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_enrollment_player_badge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades,enrollment.loInstance.loResources.resources,enrollment.learnerBadge"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    objects=[]
    try:
        for obj in req["included"]:
            objects.append(obj["id"])
        for i in args:
            if i not in objects:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_enrollment_player(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    objects=[]
    try:
        for obj in req["included"]:
            objects.append(obj["id"])
        for i in args:
            if i not in objects:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_enrollment_player_instance(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loinstance=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                loinstance.append(obj["id"])
        for i in args:
            if i not in loinstance:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_LP_enrollment_player_loresourcegrade(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresourcegrade=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResourceGrade":
                loresourcegrade.append(obj["id"])
        for i in args:
            if i not in loresourcegrade:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_enrollment_player_resource(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    resource=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="resource":
                resource.append(obj["id"])
        for i in args:
            if i not in resource:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_enrollment_player_loresource(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresource=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource":
                loresource.append(obj["id"])
        for i in args:
            if i not in loresource:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_enrollment_player_sublo(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    lo=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject":
                lo.append(obj["id"])
        for i in args:
            if i not in lo:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_enrollment_player_enrollment(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loenrollment=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstanceEnrollment":
                loenrollment.append(obj["id"])
        for i in args:
            if i not in loenrollment:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_enrollment_player(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    objects=[]
    try:
        for obj in req["included"]:
            objects.append(obj["id"])
        for i in args:
            if i not in objects:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_certificate_enrollment_player_sublo(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject":
                sublo.append(obj["id"])
        for i in args:
            if i not in sublo:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_enrollment_player_enrollmentobjects(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstanceEnrollment":
                sublo.append(obj["id"])
        for i in args:
            if i not in sublo:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_enrollment_player_loresource(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresource=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource":
                loresource.append(obj["id"])
        for i in args:
            if i not in loresource:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_enrollment_player_resource(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    resource=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="resource":
                resource.append(obj["id"])
        for i in args:
            if i not in resource:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_enrollment_player_loresourcegrade(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    resourcegrade=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResourceGrade":
                resourcegrade.append(obj["id"])
        for i in args:
            if i not in resourcegrade:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_enrollment_player_loinstance(Testcase,certificate_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades"
    data["ids"] = str(certificate_id)
    data["filter.loTypes"] = "certification"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    resourcegrade=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                resourcegrade.append(obj["id"])
        for i in args:
            if i not in resourcegrade:
                return False
        return True
    except Exception as e:
        return False




if __name__=="__main__":
    Auto_init("Player_include.csv")
    Env_init("fff02ce8-c039-4006-9d0b-48e15adfd6fa", "c560f429-c463-4815-a697-798f11136a77","113fb50b4260ab62b43ba94b5c3003d1")
    ############################## COURSE LO ###################################################################################
    test_course_enrollment_player("Test the include objects associated with player api","course:2024420","course:2024420_3703756","course:2024420_3703756_2662166_0_ca940ccf0d7c42f38edb79307eda9701_4a20e2dbaa814f118af3dbfbb72cf875","course:2024420_3703756_2662167_0_ca940ccf0d7c42f38edb79307eda9701_31991219e66d4909bbbe020bd22838c7","course:2024420_3703756_2662168_0_ca940ccf0d7c42f38edb79307eda9701_68ddc09a7ebe4cee82d5c983d933aeb8","580663_2_en-US","580668_2_en-US","580667_1_en-US","course:2024420_3703756_2662166_0","course:2024420_3703756_2662167_0","course:2024420_3703756_2662168_0","course:2024420_3703756_6530752")
    test_course_enrollment_resourceObject("Test the resource object in the include array","course:2024420","580663_2_en-US","580668_2_en-US","580667_1_en-US")
    test_course_enrollment_enrollmentobject("Test the enrollment object in the include array","course:2024420","course:2024420_3703756_6530752")
    test_course_enrollment_loresourceObject("Test the loresource objects in the include array","course:2024420","course:2024420_3703756_2662168_0","course:2024420_3703756_2662167_0","course:2024420_3703756_2662166_0")
    test_course_enrollment_loresourcegradeObject("Test the loresourcegrade object in the include array","course:2024420","course:2024420_3703756_2662166_0_ca940ccf0d7c42f38edb79307eda9701_4a20e2dbaa814f118af3dbfbb72cf875","course:2024420_3703756_2662167_0_ca940ccf0d7c42f38edb79307eda9701_31991219e66d4909bbbe020bd22838c7","course:2024420_3703756_2662168_0_ca940ccf0d7c42f38edb79307eda9701_68ddc09a7ebe4cee82d5c983d933aeb8")
    test_course_enrollment_loinstanceObject("Test the loinstance object to which learner is enrolled in iclude array","course:2024420","course:2024420_3703756")
    test_course_enrollment_player_badge("Test include array objects for include=enrollment.loResourceGrades,enrollment.loInstance.loResources.resources,enrollment.learnerBadge","course:2024420","course:2024420_3703756_6530752","course:2024420_3703756_2662168_0","course:2024420_3703756_2662167_0","course:2024420_3703756_2662166_0","580667_1_en-US","580668_2_en-US","580663_2_en-US","course:2024420_3703756_2662168_0_ca940ccf0d7c42f38edb79307eda9701_68ddc09a7ebe4cee82d5c983d933aeb8","course:2024420_3703756_2662167_0_ca940ccf0d7c42f38edb79307eda9701_31991219e66d4909bbbe020bd22838c7","course:2024420_3703756_2662166_0_ca940ccf0d7c42f38edb79307eda9701_4a20e2dbaa814f118af3dbfbb72cf875","6530752_7133_COURSE_2024420","course:2024420_3703756")
    ########################## LEARNING PROGRAM ################################################################################
    Env_init("e683c33a-dc19-4657-83c1-80c063e7f852", "c66574a7-bdae-4301-9fd8-f6b53ab7c71f","427a14964641d857c974fddfcc83e8b5")
    test_LP_enrollment_player("Test the include array objects for include=enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades","learningProgram:39806","learningProgram:39806_46675","course:2024505_3703856","course:2024506_3703857","course:2024506_3703857_2662296_0_426619ca4f4a462baf91bb77605c32cd_b92648b1767e44599bc7f82b5ae2ffeb","course:2024506_3703857_2662297_0_426619ca4f4a462baf91bb77605c32cd_804038a82778450aad1595d82c60890b","course:2024505_3703856_2662294_0_4468b84e129445d9b966cd9efb8ce5a3_f87d94e7a0d747a89181e4b1c45df5ac","course:2024505_3703856_2662295_0_4468b84e129445d9b966cd9efb8ce5a3_ff1564f64fe44399af702db37c4f1498","580668_2_en-US","580667_1_en-US","course:2024505_3703856_2662294_0","course:2024505_3703856_2662295_0","course:2024506_3703857_2662296_0","course:2024506_3703857_2662297_0","course:2024505","course:2024506","learningProgram:39806_46675_6530751","course:2024505_3703856_6530751","course:2024506_3703857_6530751")
    test_LP_enrollment_player_instance("Test the lo instance objects in include array","learningProgram:39806","learningProgram:39806_46675","course:2024505_3703856","course:2024506_3703857")
    test_LP_enrollment_player_loresourcegrade("Test the loresourcegrade objects in include array for LP enrollment","learningProgram:39806","course:2024506_3703857_2662296_0_426619ca4f4a462baf91bb77605c32cd_b92648b1767e44599bc7f82b5ae2ffeb","course:2024506_3703857_2662297_0_426619ca4f4a462baf91bb77605c32cd_804038a82778450aad1595d82c60890b","course:2024505_3703856_2662294_0_4468b84e129445d9b966cd9efb8ce5a3_f87d94e7a0d747a89181e4b1c45df5ac","course:2024505_3703856_2662295_0_4468b84e129445d9b966cd9efb8ce5a3_ff1564f64fe44399af702db37c4f1498")
    test_LP_enrollment_player_resource("Test the resource objects in the include array for LP enrollment","learningProgram:39806","580667_1_en-US","580668_2_en-US")
    test_LP_enrollment_player_loresource("Test the loresource objects in the include array","learningProgram:39806","course:2024505_3703856_2662294_0","course:2024505_3703856_2662295_0","course:2024506_3703857_2662296_0","course:2024506_3703857_2662297_0")
    test_LP_enrollment_player_sublo("Test the sublo objects in the include array","learningProgram:39806","course:2024505","course:2024506")
    test_LP_enrollment_player_enrollment("Test the enrollment objects in include array","learningProgram:39806","course:2024506_3703857_6530751","course:2024505_3703856_6530751","learningProgram:39806_46675_6530751")
    ###################### CERTIFICATION ###################################################################
    test_certificate_enrollment_player("Test the objects in the include array:include=enrollment.loInstance.subLoInstances.loResources.resources,subLOs.enrollment.loResourceGrades","certification:66271","certification:66271_99810","course:2024627_3703983","course:2024628_3703984","course:2024628_3703984_2662432_0_6b37274b47184a50bd6ca0e230aa6a72_461b5a419f4b4a38aceb364ffb3d71a7","course:2024628_3703984_2662433_0_6b37274b47184a50bd6ca0e230aa6a72_fecaaaf978d142d887ec7bcae1707fe6","course:2024627_3703983_2662430_0_adf66da25809455eb7d2b234348e5271_b1ca9ccea5c74db6b0a94be9ab11047e","course:2024627_3703983_2662431_0_adf66da25809455eb7d2b234348e5271_15ab96e4af224efe8abe5523cc884004","580668_2_en-US","580667_1_en-US","course:2024627_3703983_2662430_0","course:2024627_3703983_2662431_0","course:2024628_3703984_2662432_0","course:2024628_3703984_2662433_0","course:2024627","course:2024628","certification:66271_99810_6530751","course:2024627_3703983_6530751","course:2024628_3703984_6530751")
    test_certificate_enrollment_player_sublo("Test the subloobjects in include array","certification:66271","course:2024628","course:2024627")
    test_certificate_enrollment_player_enrollmentobjects("Test the enrollment objects in the include array", "certification:66271","certification:66271_99810_6530751","course:2024627_3703983_6530751","course:2024628_3703984_6530751")
    test_certificate_enrollment_player_loresource("Test the loresource objects in include array","certification:66271","course:2024628_3703984_2662433_0","course:2024628_3703984_2662432_0","course:2024627_3703983_2662431_0","course:2024627_3703983_2662430_0")
    test_certificate_enrollment_player_resource("Test the resource objects in the ,include array","certification:66271","580667_1_en-US","580668_2_en-US")
    test_certificate_enrollment_player_loresourcegrade("Test the loresourcegrades objects in include array","certification:66271","course:2024627_3703983_2662431_0_adf66da25809455eb7d2b234348e5271_15ab96e4af224efe8abe5523cc884004","course:2024627_3703983_2662430_0_adf66da25809455eb7d2b234348e5271_b1ca9ccea5c74db6b0a94be9ab11047e","course:2024628_3703984_2662433_0_6b37274b47184a50bd6ca0e230aa6a72_fecaaaf978d142d887ec7bcae1707fe6","course:2024628_3703984_2662432_0_6b37274b47184a50bd6ca0e230aa6a72_461b5a419f4b4a38aceb364ffb3d71a7")
    test_certificate_enrollment_player_loinstance("Test the loinstance objects in include array","certification:66271","course:2024627_3703983","course:2024628_3703984","certification:66271_99810")
    Auto_close()
