from utility import *
from time import time
import json

#skill@skill.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_shared_catalog_object(testcase,*args):
    data = get_data()
    data.clear()
    data["page[limit]"]=10
    data["page[offset]"]=0 
    try:
      res,status=get_request("catalogs/")
      if status!=200:
         raise Exception
    except Exception as e:
         return False
    try:
       if res["data"][0]["id"]==args[0] and res["data"][0]["attributes"]["name"]==args[1] and res["data"][0]["attributes"]["description"]==args[2]:
            return True
       else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_course_catalog_id(testcase,catalog_id,*args):
    data = get_data()
    data.clear()
    data["page[limit]"]=10
    data["page[offset]"]=0 
    data["filter.catalogIds"]=catalog_id
    data["filter.loTypes"]="course"
    try:
      res,status=get_request("learningObjects/")
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       course_id=[]
       for obj in res["data"]:
          course_id.append(obj["id"])
       for id in args:
          if id not in course_id:
              return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_LP_catalog_id(testcase,catalog_id,*args):
    data = get_data()
    data.clear()
    data["page[limit]"]=10
    data["page[offset]"]=0
    data["filter.catalogIds"]=catalog_id
    data["filter.loTypes"]="learningProgram"
    try:
      res,status=get_request("learningObjects/")
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       course_id=[]
       for obj in res["data"]:
          course_id.append(obj["id"])
       for id in args:
          if id not in course_id:
              return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_Certificate_catalog_id(testcase,catalog_id,*args):
    data = get_data()
    data.clear()
    data["page[limit]"]=10
    data["page[offset]"]=0
    data["filter.catalogIds"]=catalog_id
    data["filter.loTypes"]="certification"
    try:
      res,status=get_request("learningObjects/")
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       course_id=[]
       for obj in res["data"]:
          course_id.append(obj["id"])
       for id in args:
          if id not in course_id:
              return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_shared_catalog_object_id(testcase,catalog_id,*args):
    data = get_data()
    data.clear()
    data["page[limit]"]=10
    data["page[offset]"]=0 
    try:
      str1="catalogs/"+str(catalog_id)
      res,status=get_request(str1)
      if status!=200:
         raise Exception
    except Exception as e:
         return False
    try:
       if res["data"]["id"]==args[0] and res["data"]["attributes"]["name"]==args[1] and res["data"]["attributes"]["description"]==args[2]:
            return True
       else:
            return False
    except Exception as e:
        return False

if __name__=="__main__":
   Auto_init("catalog_course.csv")
   Env_init("d2962f50-2fc5-44ff-b121-f1a66fc28bf8", "2de3af33-6fb5-4b3e-9625-49b605996901","239fab80cecf817be675909d46777cc0")
   test_shared_catalog_object("Verify that the learner can view the shared catalog","14053","CATTTT","DESSS")
   test_course_catalog_id("Verify that the courses associated with shared catalog is visible to the learner","14053","course:3040538","course:3040539","course:3040540")
   test_Certificate_catalog_id("Verify the certificates associated with the shared catalog","14053","certification:67599","certification:67598","certification:67597")
   test_LP_catalog_id("Verify the LP's associated with the shared catalog","14053","learningProgram:40718","learningProgram:40716","learningProgram:40717")
   test_shared_catalog_object_id("Test the shared catalog by id","14053","14053","CATTTT","DESSS")
   Auto_close()
