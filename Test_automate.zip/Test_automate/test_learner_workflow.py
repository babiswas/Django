from utility import *
#@author Bapan Biswas

@get_request
def get_lo(*args):
    return args[1]


######################  LOResource Type  Test Code ############################################

#Test the loresource content type for the given course id.
#*args represent the loresource type strings.
@Report_generate
def test_loresource_type(TestCase,course_id,*args):
    req=None
    data=get_data()
    data.clear()
    data["include"]="instances.loResources.resources"
    data["ids"]=course_id
    data["filter.loTypes"]="course"
    try:
       req=get_lo("learningObjects")
    except Exception as e:
        return False
    lo_resource_type=[]
    for obj in req["included"]:
        if obj["type"]=="learningObjectResource":
            if obj["attributes"]["loResourceType"] not in lo_resource_type:
                lo_resource_type.append(obj["attributes"]["loResourceType"])
    print(lo_resource_type)
    for i in args:
        if i not in lo_resource_type:
            return False
    return True




#Content freeze test.
#In progress learner cannot view the updated content.
#Newly enrolled learner can view the updated content.
@Report_generate
def test_loresource_version_learner(TestCase,course_id,version,loresource_id):
    req=None
    data=get_data()
    data.clear()
    data["include"]="instances.loResources.resources"
    data["ids"]=str(course_id)
    data["filter.loTypes"]="course"
    try:
       req=get_lo("learningObjects")
    except Exception as e:
        return False
    for obj in req["included"]:
        if obj["type"]=="learningObjectResource":
            print(obj)
            if obj["id"]==loresource_id:
               if obj["attributes"]["version"]==version:
                    print(obj["attributes"]["version"])
                    return True
               else:
                    return False
    return False


############################### Module Order Test Code ########################################

#Test the module order enforced for the course LO.
#args represent the module order.
#If the module order is enforced than the function returns True else the function returns False.

@Report_generate
def test_module_order_enforced(TestCase,course_id,*args):
    req=None
    data=get_data()
    data.clear()
    data["include"]="instances"
    data["ids"]=str(course_id)
    data["filter.loTypes"]="course"
    try:
       req=get_lo("learningObjects")
    except Exception as e:
        return False
    print(req)
    lo_resources_order={}
    index=0
    try:
      if req["data"][0]["attributes"]["isSubLoOrderEnforced"]:
           for obj in req["included"][0]["relationships"]["loResources"]["data"]:
                lo_resources_order[index]=req["included"][0]["relationships"]["loResources"]["data"][index]["id"]
                index=index+1
           index=0
           print(lo_resources_order)
           for i in args:
                if lo_resources_order[index]!=i:
                    return False
                index=index+1
           return True
      else:
           return False
    except Exception as e:
           return False



#Test the course instance enrollment for the learner

@Report_generate
def test_LO_instance_enrollment(TestCase,course_id,instance_id):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        if instance_id==req["data"][0]["relationships"]["enrollment"]["data"]["id"].split('_')[1]:
            print(req["data"][0]["relationships"]["enrollment"]["data"]["id"].split('_')[1])
            return True
        else:
            return False
    except Exception as e:
        return False

############################## Multiple Delivery Type Test Code ##################################

#Test the delivery type associated with course instance.
@Report_generate
def test_delivery_type_instance_map(TestCase,course_id,instance_id,delivery_type):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresource_id=[]
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                loresource_id.append(obj)
        for obj in loresource_id:
            if obj["id"].split('_')[1]==instance_id:
                if obj["attributes"]["resourceType"]==delivery_type:
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False



#Test the multiple_delivery_type_associated with course instance.
@Report_generate
def test_multiple_delivery_type(TestCase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresource_type = []
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                loresource_type.append(obj["attributes"]["resourceType"])
        print(loresource_type)
        for i in args:
            if i not in loresource_type:
                return False
        return True
    except Exception as e:
        return False

################################## VC classroom module test Code ##############################
#Test the instructor associated with VC course.
@Report_generate
def test_instructor_VC(TestCase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    VC_instructor = []
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    for i in obj["attributes"]["instructorNames"]:
                        VC_instructor.append(i)
        print(VC_instructor)
        for i in args:
            if i not in VC_instructor:
                return False
        return True
    except Exception as e:
        return False



#Test the seatlimit associated with VC course.
@Report_generate
def test_seatlimit_VC(TestCase,course_id,seatlimit):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    print(obj["attributes"]["seatLimit"])
                    if obj["attributes"]["seatLimit"]==seatlimit:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False

#Test the location url  associated with VC course.
@Report_generate
def test_location_VC(TestCase,course_id,location):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    print(obj["attributes"]["location"])
                    if obj["attributes"]["location"]==location:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


#Test the  start date  associated with VC course.
@Report_generate
def test_datestart_VC(TestCase,course_id,startdate):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    print(obj["attributes"]["dateStart"])
                    if obj["attributes"]["dateStart"]==startdate:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


#Test the  start date  associated with VC course.
@Report_generate
def test_deadline_VC(TestCase,course_id,deadline):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    print(obj["attributes"]["completionDeadline"])
                    if obj["attributes"]["completionDeadline"]==deadline:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False



#Test the  start date  associated with VC course.
@Report_generate
def test_desiredduration_VC(TestCase,course_id,desiredduration):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    print(obj["attributes"]["desiredDuration"])
                    if obj["attributes"]["desiredDuration"]==desiredduration:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


#Test the multiday session for the  VC course.
@Report_generate
def test_multiday_VC(TestCase,course_id,desiredduration):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Virtual Classroom":
                    print(obj["attributes"]["desiredDuration"])
                    if obj["attributes"]["desiredDuration"]==desiredduration:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


########################## Class Room module Test Code #####################################

#Test the instructor associated with VC course.
@Report_generate
def test_instructor_CR(TestCase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    CR_instructor = []
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Classroom":
                    for i in obj["attributes"]["instructorNames"]:
                        CR_instructor.append(i)
        print(CR_instructor)
        for i in args:
            if i not in CR_instructor:
                return False
        return True
    except Exception as e:
        return False



#Test the location url  associated with VC course.
@Report_generate
def test_location_CR(TestCase,course_id,location):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Classroom":
                    print(obj["attributes"]["location"])
                    if obj["attributes"]["location"]==location:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False

#Test the seatlimit associated with CR module.
@Report_generate
def test_seatlimit_CR(TestCase,course_id,seatlimit):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Classroom":
                    print(obj["attributes"]["seatLimit"])
                    if obj["attributes"]["seatLimit"]==seatlimit:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


#Test the  deadline  associated with CR course.
@Report_generate
def test_deadline_CR(TestCase,course_id,deadline):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Classroom":
                    print(obj["attributes"]["completionDeadline"])
                    if obj["attributes"]["completionDeadline"]==deadline:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


#Test the  start date  associated with VC course.
@Report_generate
def test_desiredduration_CR(TestCase,course_id,desiredduration):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Classroom":
                    print(obj["attributes"]["desiredDuration"])
                    if obj["attributes"]["desiredDuration"]==desiredduration:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


#Test the  start date  associated with CR course.
@Report_generate
def test_datestart_CR(TestCase,course_id,startdate):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "resource":
                if obj["attributes"]["contentType"]=="Classroom":
                    print(obj["attributes"]["dateStart"])
                    if obj["attributes"]["dateStart"]==startdate:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False

################################################ Activity Module Test Code ######################
#Test the lresourcetype of the loresource.
@Report_generate
def test_resource_type_Activity(TestCase,course_id):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                if obj["attributes"]["resourceType"]=="Activity":
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False


#Test the submission enabled value for the loresource.
@Report_generate
def test_submissonenabled_Activity(TestCase,course_id,submissionenabled):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                if obj["attributes"]["submissionEnabled"]==submissionenabled:
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False


#Test the resource subtype for the Activity module.
@Report_generate
def test_resource_subtype_Activity(TestCase,course_id,subtype):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                print()
                if obj["attributes"]["resourceSubType"]==subtype:
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False


#Test the submission state for the Activity module.
@Report_generate
def test_submissionstate_Activity(TestCase,course_id,state):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                if obj["attributes"]["submissionState"]==state:
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False

#Test the submission url for the Activity module.
@Report_generate
def test_submissionurl_Activity(TestCase,course_id,url):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] == "learningObjectResource":
                if obj["attributes"]["submissionUrl"].split('?')[0]==url:
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False

#################### Test Activity REsource ####################################################
#Test the instructor associated with Activity module.
@Report_generate
def test_instructor_Activity(TestCase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    instructor=[]
    try:
        for obj in req["included"]:
            if (obj["type"] == "resource") and (obj["attributes"]["contentType"]=="Activity"):
                for i in obj["attributes"]["instructorNames"]:
                    instructor.append(i)
        for i in args:
            if i not in instructor:
               return False
        return True
    except Exception as e:
        return False


#Test the content type associated with the course.
@Report_generate
def test_contenttype_Activity(TestCase,course_id):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    data["filter.loTypes"] = "course"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if (obj["type"] == "resource") and (obj["attributes"]["contentType"]=="Activity"):
                return True
        return False
    except Exception as e:
        return False


if __name__=="__main__":
    Auto_init("Learner_Workflow.csv")
    ################### Pre Work,Test Out,Content #############################################
    Env_init("e683c33a-dc19-4657-83c1-80c063e7f852","c66574a7-bdae-4301-9fd8-f6b53ab7c71f","427a14964641d857c974fddfcc83e8b5")
    test_loresource_type("Test the loresource type in the api response","course:2020873","Test Out","Content","Pre Work")

    #############################  Content Freeze ##############################################
    test_loresource_version_learner("Test the loresource version for the in progress learner","course:2020879",1,"course:2020879_3699947_2658081_0")
    Env_init("fff02ce8-c039-4006-9d0b-48e15adfd6fa", "c560f429-c463-4815-a697-798f11136a77","113fb50b4260ab62b43ba94b5c3003d1")
    test_loresource_version_learner("Test the loresource version for the newly enrolled learner","course:2020879",2,"course:2020879_3699947_2658081_0")

    ####################### Module Order & LO_instance_enrollment #####################################
    Env_init("e683c33a-dc19-4657-83c1-80c063e7f852","c66574a7-bdae-4301-9fd8-f6b53ab7c71f","427a14964641d857c974fddfcc83e8b5")
    test_module_order_enforced("Test the module order enforced for the course","course:2020881","course:2020881_3699949_2658087_0","course:2020881_3699949_2658089_0","course:2020881_3699949_2658088_0")
    test_LO_instance_enrollment("Test the course instance enrollment for the learner","course:2020881","3700791")
    #####################  Test the Multiple Delivery Type ##########################################
    test_delivery_type_instance_map("Test the VC delivery type associated with course instance","course:2021715","3700793","Virtual Classroom")
    test_delivery_type_instance_map("Test the class room delivery type associated with course instance", "course:2021715","3700795","Classroom")
    test_delivery_type_instance_map("Test the Activity delivery type associated with course instance", "course:2021715","3700794","Activity")
    test_delivery_type_instance_map("Test the Elearning delivery type associated with course instance", "course:2021715","3700792","Elearning")
    test_multiple_delivery_type("Test the multiple delivery type associated with course","course:2021715","Classroom","Activity","Virtual Classroom","Elearning")
    ########################### Virtual Class Room Module ###################################
    test_instructor_VC("Test the instructor associated with VC","course:2021716","BG","BGHJJJJ","MGGGG")
    test_seatlimit_VC("Test the seat limit associated with VC module","course:2021716",21)
    test_location_VC("Test the location url associated with VC module","course:2021716","https://jira.corp.adobe.com/secure/Dashboard.jspa")
    test_datestart_VC("Test the start date associated with VC","course:2021716","2024-11-19T19:30:00.000Z")
    test_deadline_VC("Test the deadline associated with VC","course:2021716","2024-11-19T20:30:00.000Z")
    test_desiredduration_VC("Test the desired duration associated with VC","course:2021716",3600)
    test_multiday_VC("Test the multiday VC class room session","course:2021732",10800)
    #################### Class Room Module ##################################################
    test_instructor_CR("Test the instructor associated with CR module","course:2021735","BGHJJJJ","MGGGG")
    test_location_CR("Test the location associated with the CR module","course:2021735","Bangalore")
    test_seatlimit_CR("Test the seatlimit associated with CR module","course:2021735",43)
    test_deadline_CR("Test the deadline associated with CR module","course:2021735","2025-11-18T20:30:00.000Z")
    test_desiredduration_CR("Test the desiredduration for the CR module","course:2021735",3600)
    test_datestart_CR("Test the startdate associated with CR module","course:2021735","2025-11-18T19:30:00.000Z")
    ########################### Activity  Module [Loresource]###############################################
    Env_init("fff02ce8-c039-4006-9d0b-48e15adfd6fa", "c560f429-c463-4815-a697-798f11136a77","113fb50b4260ab62b43ba94b5c3003d1")
    test_resource_type_Activity("Test the resource type of the loresource","course:2021736")
    test_submissonenabled_Activity("Test the submission enabled state of the course","course:2021736",True)
    test_resource_subtype_Activity("Test the resource subtype for the Activity module","course:2021736","SUBMISSION")
    test_submissionstate_Activity("Test the submission state of the File submission Activity","course:2021736","PENDING_APPROVAL")
    test_submissionurl_Activity("Test the submission url for the Activity module","course:2021736","https://cpcontentsdev.adobe.com/public/account/5654/accountassets/5654/userassets/6530752/usersubmissions/enms/176542/mongodb2.txt")
    ######################  Activity Module [Resource] #######################################################
    test_contenttype_Activity("Test the contenttype of the loresource","course:2021736")
    test_instructor_Activity("Test the instructor associated with the course","course:2021736","Bapan Biswas")
    Auto_close()


