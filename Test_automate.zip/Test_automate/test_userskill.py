from utility import *

@get_request
def get_skill(*args):
    return args[1],args[2]

@Report_generate
def test_skill_attributes_user_skill(Testcase,userid,user_skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(user_skill_id)
    try:
        str1="users/"+str(userid)+"/userSkills"
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if req["data"][0]["attributes"]["pointsEarned"]==args[0] and req["data"][0]["attributes"]["dateAchieved"]==args[1] and req["data"][0]["attributes"]["dateCreated"]==args[2]:
           return True
        else:
           return False
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_relationship_user_skill(Testcase,userid,user_skill_id,*args):	
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(user_skill_id)
    try:
        str1="users/"+str(userid)+"/userSkills"
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if req["data"][0]["relationships"]["learnerBadge"]["data"]["id"]==args[0]:
           return True
        else:
           return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_relationship_user_skill(Testcase,userid,user_skill_id,*args):	
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(user_skill_id)
    try:
        str1="users/"+str(userid)+"/userSkills"
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if req["data"][0]["relationships"]["learnerBadge"]["data"]["id"]==args[0]:
           return True
        else:
           return False
    except Exception as e:
        return False


@Report_generate
def test_learningobject_relationship_user_skill(Testcase,userid,user_skill_id,*args):	
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(user_skill_id)
    try:
        str1="users/"+str(userid)+"/userSkills"
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        lo_id=[]
        for obj in req["data"][0]["relationships"]["learningObject"]["data"]:
           	lo_id.append(obj["id"])
        for id in args:
           if id not in lo_id:
              return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skilllevel_relationship_user_skill(Testcase,userid,user_skill_id,*args):	
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(user_skill_id)
    try:
        str1="users/"+str(userid)+"/userSkills"
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if req["data"][0]["relationships"]["skillLevel"]["data"]["id"]==args[0]:
           return True
        else:
           return False
    except Exception as e:
        return False

if __name__=="__main__":
    Auto_init("userskill_body.csv")
    Env_init("d2962f50-2fc5-44ff-b121-f1a66fc28bf8", "2de3af33-6fb5-4b3e-9625-49b605996901","239fab80cecf817be675909d46777cc0")
    test_skill_attributes_user_skill("Verify the attributes associated with userskill","7273699","7273699_44018_1",30.2,"2020-03-10T07:12:36.000Z","2020-03-10T07:12:20.000Z")
    test_learnerbadge_relationship_user_skill("Verify the userbadge associated with userskill","7273699","7273699_44018_1","7273699_7382_COMPETENCY_44018_1")
    test_learningobject_relationship_user_skill("Verify the learning objects associated with userskill","7273699","7273699_44018_1","course:3040114","course:3040115","course:3040116")
    test_skilllevel_relationship_user_skill("Verify the user skilllevel associated with userskill","7273699","7273699_44018_1","44018_1")
    Auto_close()