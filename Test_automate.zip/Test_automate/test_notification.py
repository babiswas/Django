from utility import *
from time import time
import json
#ann@ann.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@patch_request_announcement
def patch_request(*args):
    return args[2]


def pagination(total_data,page_limit,endpoint):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[cursor]"]=0
    data["announcementsOnly"]=False
    data["userSelectedChannels"]="announcement::received"
    has_next=True
    while has_next:
       url=endpoint
       res,status=get_request(url)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[cursor]"]=res["links"]["next"].split('?')[1].split('&')[-1].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False              
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True


@Report_generate
def test_pagination(testcase,total_data,page_limit,endpoint):
    try:
       result=pagination(total_data,page_limit,endpoint)
       return result
    except Exception as e:
        return False


class Notification:
    def __init__(self,id):
        self.id=id
        self.type="userNotification"
        self.attributes={"actionTaken":False,"channel": "announcement::received","read":True}

    def construct_payload(self):
        payload={'data':self.__dict__}
        return json.dumps(payload)

    def set_attributes_read(self,status):
        self.attributes["read"]=status

    def set_attributes_actiontaken(self,status):
        self.attributes["actionTaken"] = status



@Report_generate
def test_update_announcement_read_status(testcase,id,userid,read):
    try:
       notification=Notification(id)
       notification.set_attributes_read(read)
       payload=notification.construct_payload()
       url="users/"+str(userid)+"/userNotifications/"+str(id)
       status=patch_request(url,payload)
       if status!=204:
          return False
       url1="users/"+str(userid)+"/userNotifications"
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[offset]"]=0
       data["announcementsOnly"]=False
       data["userSelectedChannels"]="announcement::received"
       res,status_get=get_request(url1)
       if status_get!=200:
          return False
    except Exception as e:
       return False
    try:
       for obj in res["data"]:
           if obj["id"]==str(id):
               if obj["attributes"]["read"] == read:
                   return True
               else:
                   return False
       return False
    except Exception as e:
       return False


@Report_generate
def test_update_announcement_actiontaken(testcase,id,userid,read):
    try:
       notification=Notification(id)
       notification.set_attributes_actiontaken(read)
       payload=notification.construct_payload()
       url="users/"+str(userid)+"/userNotifications/"+str(id)
       status=patch_request(url,payload)
       if status!=204:
          return False
       url1="users/"+str(userid)+"/userNotifications"
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[offset]"]=0
       data["announcementsOnly"] = False
       data["userSelectedChannels"] = "announcement::received"
       res,status_get=get_request(url1)
       if status_get!=200:
          return False
    except Exception as e:
       return False
    try:
        for obj in res["data"]:
            if obj["id"] == str(id):
                if obj["attributes"]["actionTaken"] == read:
                    return True
                else:
                    return False
        return False
    except Exception as e:
       return False

@Report_generate
def test_announcement_content_type(testcase,id,contenttype,userid):
    try:
        data=get_data()
        data["page[limit]"]=10
        data["page[offset]"]=0
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1="users/"+str(userid)+"/userNotifications"
        res,status=get_request(url1)
        if status!=200:
            return False
    except Exception as e:
        return False
    try:
        for obj in res["data"]:
            if obj["id"]==id:
                if obj["attributes"]["announcement"]["contentType"] == contenttype:
                    return True
                else:
                    return False
    except Exception as e:
        return False

@Report_generate
def test_announcement_deleted(testcase,id,isdeleted,userid):
    try:
        data = get_data()
        data["page[limit]"] = 10
        data["page[offset]"] = 0
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        for obj in res["data"]:
            if obj["id"]==id:
                if obj["attributes"]["announcement"]["isDeleted"] == isdeleted:
                    return True
                else:
                    return False
    except Exception as e:
        return False

@Report_generate
def test_announcement_sticky(testcase,id,issticky,userid):
    try:
        data = get_data()
        data["page[limit]"] = 10
        data["page[offset]"] = 0
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        for obj in res["data"]:
            if obj["id"]==id:
                if obj["attributes"]["announcement"]["sticky"] == issticky:
                    return True
                else:
                    return False
    except Exception as e:
        return False



@Report_generate
def test_announcement_modeltype(testcase,userid):
    try:
        data = get_data()
        data["page[limit]"] = 10
        data["page[offset]"] = 0
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        for obj in res["data"]:
            if obj["attributes"]["modelTypes"][0]!="announcement":
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_announcement_channel(testcase,offset,channel,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"][ "channel"]==channel:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_announcement_modelname(testcase,id,modelname,userid):
    try:
        data = get_data()
        data["page[limit]"] = 10
        data["page[offset]"] = 0
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        for obj in res["data"]:
            if obj["id"]==id:
                if obj["attributes"]["modelNames"][0]==modelname:
                    return True
                else:
                    return False
    except Exception as e:
        return False


@Report_generate
def test_announcement_expirydate(testcase,id,expirydate,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        data["announcementsOnly"] = False
        data["userSelectedChannels"] = "announcement::received"
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["announcement"]["expiryDate"]==expirydate:
            return True
        else:
            return False
    except Exception as e:
        return False



if __name__=="__main__":
   Auto_init("Announcement.csv")
   Env_init("4a8007fc-872a-4e36-a41b-9b06f5956a72","67a69871-be43-441c-9621-a506014cacd0","036a8bd5e3f4f6ba91cb526f630b0ec5")
   test_update_announcement_read_status("Update the read status to True and verify using GET","19975276","7581731",True)
   test_update_announcement_actiontaken("Update the action taken status to True and verify using GET","19975276","7581731",True)
   test_update_announcement_actiontaken("Update the action taken status to False and verify using GET", "19975276","7581731",False)
   test_update_announcement_read_status("Update the read status to False and verify using GET","19975276","7581731",False)
   test_update_announcement_read_status("Update the read status of video announcement from False to True","19975268","7581731",True)
   test_update_announcement_read_status("Update the read status of the video announcement from True to False","19975268","7581731",False)
   test_update_announcement_read_status("Update the read status of the Audio announcement from False to True","19975272","7581731",True)
   test_update_announcement_read_status("Update the read status of the audio announcement from True to False","19975272","7581731",False)
   test_announcement_deleted("Verify the deleted status of the deleted announcement object","19975274",True,"7581731")
   test_announcement_deleted("Verify the deleted status of the Active announcement object", "19975276",False,"7581731")
   test_announcement_sticky("Verify the attribute sticky for sticky announcement","19975266",True,"7581731")
   test_announcement_sticky("Verify the attribute sticky for announcement not sticky", "19975268",False, "7581731")
   test_announcement_content_type("Verify the contentype field of video content","19975272","VIDEO","7581731")
   test_announcement_content_type("Verify the contentype field of image content","19975276","IMAGE","7581731")
   test_announcement_content_type("Verify the contentype field of audio content","19975268","AUDIO","7581731")
   test_announcement_modeltype("Verify that modeltype of the announcement object","7581731")
   test_announcement_modelname("Verify the modelname of the deleted announcement", "19975274","DELETED_ANNOUNCEMENT","7581731")
   Env_init("794ee314-acb2-41da-bbaf-44bd41aa228e","8e0cdef8-78ba-4da7-9aa3-16776c0e0fa6","42b7e2b482f721f7909f8d6975aed6a8")
   test_pagination("Test the pagination related to announcement with page limit 10",17,10,"users/7582067/userNotifications")
   test_pagination("Test the pagination related to announcement with page limit 6", 17,6,"users/7582067/userNotifications")
   test_pagination("Test the pagination related to announcement with page limit 4", 17,4,"users/7582067/userNotifications")
   Auto_close()
