from utility import *
from time import time
import json

#taga@faga.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_tag_Course(testcase,tag_value,*args):
    data = get_data()
    data.clear()
    data["filter.tagName"] = tag_value
    data["page[offset]"] =0
    data["page[limit]"]=10
    data["filter.loTypes"] = "course"
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          if obj["attributes"]["tags"][0]!=tag_value:
               return False
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=5:
          return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_2tag_Course(testcase,tag_value1,tag_value2,*args):
    data = get_data()
    data.clear()
    data["filter.tagName"] = tag_value1+","+tag_value2
    data["filter.loTypes"] ="course"
    data["page[limit]"]=10
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          if obj["attributes"]["tags"][0]==tag_value1 or obj["attributes"]["tags"][0]==tag_value2:
               pass
          else:
              return False
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=10:
          return False
       return True
    except Exception as e:
        return False






if __name__=="__main__":
   Auto_init("Tag_course.csv")
   Env_init("7a5fca40-1013-4166-bb92-cee58a43a980","54cda52b-f078-42e3-8a75-ad3b605166f7","31cafab8def2491b6bd0395dd72974c8")
   test_tag_Course("Test the tag1 course in prime account","tag1","course:3038848","course:3038851","course:3038849","course:3038850","course:3038852")
   test_tag_Course("Test the tag2 course in prime account","tag2","course:3038856","course:3038854","course:3038855","course:3038857","course:3038853")
   test_tag_Course("Test the tag3 course in prime account","tag3","course:3038858","course:3038861","course:3038859","course:3038860","course:3038862")
   test_tag_Course("Test the tag4 course in prime account","tag4","course:3038866","course:3038867","course:3038864","course:3038863","course:3038865")
   test_2tag_Course("Test the tag1/tag2 course in prime account","tag1","tag2","course:3038857","course:3038856","course:3038854","course:3038855","course:3038848","course:3038851","course:3038849","course:3038850","course:3038852","course:3038853")
   test_2tag_Course("Test the tag2/tag3 course in prime account","tag2","tag3","course:3038857","course:3038856","course:3038854","course:3038855","course:3038858","course:3038861","course:3038853","course:3038859","course:3038860","course:3038862")
   test_2tag_Course("Test the tag3/tag4 course in prime account","tag3","tag4","course:3038858","course:3038861","course:3038866","course:3038867","course:3038859","course:3038860","course:3038862","course:3038864","course:3038863","course:3038865")
   Auto_close()
