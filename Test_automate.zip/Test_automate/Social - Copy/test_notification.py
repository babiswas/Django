from utility import *
from time import time
import json
#ann@ann.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@patch_request_payload_statuscode
def patch_request(*args):
    return args[2]


def pagination(total_data,page_limit,endpoint):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[offset]"]=0
    has_next=True
    while has_next:
       url=endpoint
       res,status=get_request(url)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False              
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True


@Report_generate
def test_pagination(testcase,total_data,page_limit,endpoint):
    try:
       result=pagination(total_data,page_limit,endpoint)
       return result
    except Exception as e:
        return False


class Notification:
    def __init__(self,id):
        self.id=id
        self.type="userNotification"
        self.attributes={"actionTaken":false,"channel": "announcement::received","read":true}

    def construct_payload(self):
        payload={'data':self.__dict__}
        return json.dumps(payload)

    def set_attributes_read(self,status):
        self.attributes["read"]=status

    def set_attributes_actiontaken(self,status):
        self.attributes["actionTaken"] = status



@Report_generate
def test_update_announcement_read_status(testcase,id,userid,status):
    try:
       notification=Notification(id)
       notification.set_attributes_read(status)
       payload=notification.construct_payload()
       url="users/"+str(userid)+"/userNotifications/"+str(id)
       res,status=patch_request(url,payload)
       if status!=204:
          return False
       url1="users/"+str(userid)+"/userNotifications"
       data=get_data()
       data.clear()
       data["page[limit]"]=1
       data["page[offset]"]=0
       res,status_get=get_request(url1)
       if status_get!=200:
          return False
    except Exception as e:
       return False
    try:
       if res["data"][0]["attributes"]["read"]==status:
          return True
       else:
          return False
    except Exception as e:
       return False


@Report_generate
def test_update_announcement_actiontaken(testcase,id,userid,status):
    try:
       notification=Notification(id)
       notification.set_attributes_actiontaken(status)
       payload=notification.construct_payload()
       url="users/"+str(userid)+"/userNotifications/"+str(id)
       res,status=patch_request(url,payload)
       if status!=204:
          return False
       url1="users/"+str(userid)+"/userNotifications"
       data=get_data()
       data.clear()
       data["page[limit]"]=1
       data["page[offset]"]=0
       res,status_get=get_request(url1)
       if status_get!=200:
          return False
    except Exception as e:
       return False
    try:
       if res["data"][0]["attributes"]["actionTaken"]==status:
          return True
       else:
          return False
    except Exception as e:
       return False

@Report_generate
def test_announcement_content_type(testcase,offset,contenttype,userid):
    try:
        data=get_data()
        data["page[limit]"]=1
        data["page[offset]"]=offset
        url1="users/"+str(userid)+"/userNotifications"
        res,status=get_request(url1)
        if status!=200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["announcement"]["contentType"]==contenttype:
            return True
        else:
            return False
    except Exception as e:
        return False

@Report_generate
def test_announcement_deleted(testcase,offset,isdeleted,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["announcement"]["isDeleted"] == isdeleted:
            return True
        else:
            return False
    except Exception as e:
        return False

@Report_generate
def test_announcement_sticky(testcase,offset,issticky,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["announcement"]["sticky"] == issticky:
            return True
        else:
            return False
    except Exception as e:
        return False



@Report_generate
def test_announcement_modeltype(testcase,offset,modeltype,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["modelTypes"][0] == modeltype:
            return True
        else:
            return False
    except Exception as e:
        return False

@Report_generate
def test_announcement_channel(testcase,offset,channel,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"][ "channel"]==channel:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_announcement_modelname(testcase,offset,modelname,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["modelNames"][0]==modelname:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_announcement_expirydate(testcase,offset,expirydate,userid):
    try:
        data = get_data()
        data["page[limit]"] = 1
        data["page[offset]"] = offset
        url1 = "users/" + str(userid) + "/userNotifications"
        res, status = get_request(url1)
        if status != 200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"][0]["attributes"]["announcement"]["expiryDate"]==expirydate:
            return True
        else:
            return False
    except Exception as e:
        return False


if __name__=="__main__":
   Auto_init("Announcement.csv")
   Env_init("7a5fca40-1013-4166-bb92-cee58a43a980","54cda52b-f078-42e3-8a75-ad3b605166f7","31cafab8def2491b6bd0395dd72974c8")
   Auto_close()
