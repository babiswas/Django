from utility import *
from time import time
import json

@get_request
def get_request(*args):
    return args[1],args[2]

@post_request_payload
def post_request(*args):
    return args[2],args[3]

@patch_request_payload
def patch_request(*args):
    return args[2],args[3]

class Create_Board:
   def __init__(self):
      self.type="board"
      self.attributes={'description':'','name':'','postingAllowed':'','state':'','visibility':''}
      self.relationships={'skills':{'data':[{'id':'','type':'skill'}]}}

   def construct_payload(self):
       payload={'data':self.__dict__}
       return json.dumps(payload)

   def set_attributes(self,*args):
       self.attributes['description']=args[0]
       self.attributes['name']=args[1]
       self.attributes['postingAllowed']=args[2]
       self.attributes['state']=args[3]
       self.attributes['visibility']=args[4]
       return self

   def add_skill(self,id):
       self.relationships['skills']['data'].append({'id':id,'type':'skill'})
       return self

   def set_skill(self,id):
       self.relationships['skills']['data'][0]['id']=id
       return self

   def change_description(self,description):
       self.attributes['description']=description
       return self

   def change_name(self,name):
       self.attributes['name']=name
       return self

   def change_state(self,state):
       self.attributes['state']=state
       return self

   def change_visiblity(self,visibility):
       self.attributes['visibility']=visibility
       return self

   def change_postingAllowed(self,Allowed):
       self.attributes['postingAllowed']=Allowed
       return self


class Update_Board:
   def __init__(self,id):
      self.id=id
      self.type="board"
      self.attributes={'description':'','name':'','postingAllowed':'','state':'','visibility':''}
      self.relationships={'skills':{'data':[{'id':'','type':'skill'}]}}

   def construct_payload(self):
       payload={'data':self.__dict__}
       return json.dumps(payload)

   def set_attributes(self,*args):
       self.attributes['description']=args[0]
       self.attributes['name']=args[1]
       self.attributes['postingAllowed']=args[2]
       self.attributes['state']=args[3]
       self.attributes['visibility']=args[4]
       return self

   def add_skill(self,id):
       self.relationships['skills']['data'].append({'id':id,'type':'skill'})
       return self

   def set_skill(self,id):
       self.relationships['skills']['data'][0]['id']=id
       return self

   def change_description(self,description):
       self.attributes['description']=description
       return self

   def change_name(self,name):
       self.attributes['name']=name
       return self

   def change_state(self,state):
       self.attributes['state']=state
       return self

   def change_visiblity(self,visibility):
       self.attributes['visibility']=visibility
       return self

   def change_postingAllowed(self,Allowed):
       self.attributes['postingAllowed']=Allowed
       return self


@Report_generate
def test_create_board(testcase,*args):
    try:
        c=Create_Board()
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5])
        payload=c.construct_payload()
        res,status=post_request("boards",payload)
        if status!=200:
            raise Exception
        try:
            board_id=res["data"]["id"]
            url="boards/"+str(board_id)
            resp,status=get_request(url)
            if status!=200:
                raise Exception
            if resp["data"]["id"]==res["data"]["id"] and resp["data"]["attributes"]["name"]==res["data"]["attributes"]["name"] and resp["data"]["attributes"]["state"]==res["data"]["attributes"]["state"] and resp["data"]["attributes"]["visibility"]==res["data"]["attributes"]["visibility"]:
                if resp["data"]["attributes"]["name"]==args[1] and resp["data"]["attributes"]["visibility"]==args[4] and resp["data"]["relationships"]["skills"]["data"][0]["id"]==args[5]:
                    return True
                else:
                    return False
            else:
                return False
        except Exception as e:
            return False
    except Exception as e:
        return False


@Report_generate
def test_update_board(testcase,id,*args):
    try:
        c=Create_Board(id)
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5])
        payload=c.construct_payload()
        url="boards/"+str(c.id)
        res,status=patch_request(url,payload)
        if status!=200:
            raise Exception
        try:
            board_id=res["data"]["id"]
            url="boards/"+str(board_id)
            resp,status=get_request(url)
            if status!=200:
                raise Exception
            if resp["data"]["id"]==res["data"]["id"] and resp["data"]["attributes"]["name"]==res["data"]["attributes"]["name"] and resp["data"]["attributes"]["state"]==res["data"]["attributes"]["state"] and resp["data"]["attributes"]["visibility"]==res["data"]["attributes"]["visibility"]:
                if resp["data"]["attributes"]["name"]==args[1] and resp["data"]["attributes"]["visibility"]==args[4] and resp["data"]["relationships"]["skills"]["data"][0]["id"]==args[5]:
                    return True
                else:
                    return False
            else:
                return False
        except Exception as e:
            return False
    except Exception as e:
        return False
           
if __name__=="__main__":
   Auto_init("social_board.csv")
   Env_init("5485feb6-c75e-4446-a8be-6158b247e0ee","a5bca1ce-5dd8-46df-87d6-8f4e9a299fca","9ed175fa764b9791e1e48debf3fcf0fd")
   for i in range(30):
       test_create_board(testcase,*args)
   Auto_close()
