from utility import *
import json

class User:
    def __init__(self,id):
        self.id=id
        self.type="user"
        self.attributes={"email":'',"name":'',"roles":[],"userUniqueId":''}
        self.relationships={"account":{"data":{"id":"","type":"account"}},"manager":{"data":{"id":"","type":"user"}}}

    @property
    def set_attributes(self):
        return self.attributes

    @set_attributes.setter
    def set_attributes(self,**kwargs):
        self.attributes.clear()
        for key,value in kwargs:
            self.attributes[key]=value
    @property
    def set_relationship(self):
        return self.relationship

    @set_relationship.setter
    def set_relationship(self,**kwargs):
        self.relationships.clear()
        for key,value in kwargs:
            self.relationships[key]=value

    def create_payload(self):
        body={"data":self.__dict__}
        return json.dumps(body)

    def add_roles(self,role):
        if "roles" in self.attributes:
            if role not in self.attributes["roles"]:
                self.attributes["roles"].append(role)

    def add_multiple_roles(self,*args):
        if "roles" in self.attributes:
            for role in args:
                if role not in self.attributes["roles"]:
                    self.attributes["roles"].append(role)

    def clear_roles(self,*args):
        if "roles" in self.attributes:
            self.attributes["roles"].clear()

    def remove_roles(self,role):
        if "roles" in self.attributes:
            if role in self.attributes["roles"]:
                self.attributes["roles"].remove(role)

    def modify_uuid(self,uuid):
        if "userUniqueId" in self.attributes:
            self.attributes["userUniqueId"]=uuid

    def modify_email(self,email):
        if "email" in self.attributes:
            self.attributes["email"]=email

    def modify_name(self,name):
        if "name" in self.attributes:
            self.attributes["name"]=name

    def modify_manager(self,managerid):
        if "manager" in self.relationships:
            self.relationships["manager"]["data"]["id"]=str(managerid)

    def modify_account(self,accountid):
        if "account" in self.relationships:
            self.relationships["account"]["data"]["id"] = str(accountid)


@get_request
def get_request(*args):
    return args[1],args[2]

@patch_request_payload
def patch_request(*args):
    return args[2],args[3]


@Report_generate
def test_patch_user_basic(testcase,obj,*args):
    data = get_data()
    data.clear()
    try:
        str1="users/"+obj.id
        payload=obj.create_payload()
        res,status=patch_request(str1,payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["email"]==args[0] and res["data"]["attributes"]["userUniqueId"]==args[1] and res["data"]["attributes"]["name"]==args[2]:
            return True
        return False
    except Exception as e:
        return False


@Report_generate
def test_patch_user_email_update(testcase,obj,email):
    data = get_data()
    data.clear()
    try:
        obj.modify_email(email)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["email"]==email:
            return True
        return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_name_update(testcase,obj,name):
    data = get_data()
    data.clear()
    try:
        obj.modify_name(name)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
       if res["data"]["attributes"]["name"]==name:
          return True
       return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_role_add(testcase,obj,role):
    data = get_data()
    data.clear()
    try:
        obj.add_roles(role)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if role in res["data"]["attributes"]["roles"]:
            return True
        return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_role_remove(testcase,obj,role):
    data = get_data()
    data.clear()
    try:
        obj.remove_roles(role)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if role not in res["data"]["attributes"]["roles"]:
            return True
        return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_uuid_update(testcase,obj,uuid):
    data = get_data()
    data.clear()
    try:
        obj.modify_uuid(uuid)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            return Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["userUniqueId"]==uuid:
            return True
        return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_manager_update(testcase,obj,managerid):
    data = get_data()
    data.clear()
    try:
        obj.modify_manager(managerid)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["relationships"]["manager"]["data"]["id"]==managerid:
            return True
        return False
    except Exception as e:
        return False


@Report_generate
def test_patch_user_verify_GET(testcase,obj,*args):
    data = get_data()
    data.clear()
    try:
        str1="users/"+obj.id
        obj.modify_email(args[0])
        obj.modify_uuid(args[1])
        obj.modify_name(args[2])
        payload=obj.create_payload()
        res,status=patch_request(str1,payload)
        if status!=200:
            raise Exception
        res1,status=get_request(str1)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["email"]==res1["data"]["attributes"]["email"] and res["data"]["attributes"]["userUniqueId"]==res1["data"]["attributes"]["userUniqueId"] and res["data"]["attributes"]["name"]==res1["data"]["attributes"]["name"]:
            return True
        return False
    except Exception as e:
        return False


if __name__=="__main__":
   Auto_init("custom_role.csv")
   Env_init("e7a8d6c4-5dd5-4286-b65e-35e44fea62dd","bde31eca-dbeb-49e8-801d-0e182c68448b","4c1ded7e1e090437e09616c92b8f3343")
   user=User("7475530")
   user.modify_uuid("BALLLL")
   user.modify_email("customrole100@custom.com")
   user.modify_name("custom custom")
   user.modify_manager("7475525")
   user.modify_account("6086")
   user.add_multiple_roles("Learner","Role Config Role")
   test_patch_user_basic("Verify the basic functionality of PATCH user having custom role",user,"customrole100@custom.com","BALLLL","custom custom")
   test_patch_user_email_update("Verify the email update for the user having custom role",user,"mnb@mnb.com")
   test_patch_user_name_update("Verify the user name update for the user having custom role",user,"MP MP")
   test_patch_user_role_add("Verify if author role can be associated with the user having custom role",user,"Author")
   test_patch_user_role_remove("Verify if the author role can be removed from the user having custom role",user,"Author")
   test_patch_user_role_add("Verify if IntegrationAdmin role can be associated with the user having custom role", user, "Integration Admin")
   test_patch_user_role_remove("Verify if the IntegrationAdmin role can be removed from the user having custom role",user,"Integration Admin")
   test_patch_user_uuid_update("Verify if the uuid update for the user having custom role",user,"MSD_12")
   test_patch_user_manager_update("Verify the manager update for the user having custom role",user,"7475531")
   test_patch_user_verify_GET("Verify the email,uuid,name update validate using GET",user,"taba@taba.com","MKO_345","DISHOOM")
   user.modify_uuid("BALLLL")
   user.modify_email("customrole100@custom.com")
   user.modify_name("custom custom")
   user.modify_manager("7475525")
   user.modify_account("6086")
   user.add_multiple_roles("Learner","Role Config Role")
   test_patch_user_basic("Verify the basic functionality of PATCH user having custom role",user,"customrole100@custom.com","BALLLL","custom custom")
   Auto_close()