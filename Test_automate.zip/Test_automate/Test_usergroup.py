from utility import *
from time import time
import json
from functools import wraps
from time import sleep


UserGroup={
  "data": [
    {
      "type": "user",
      "id": "5629038"
    }
  ]
}


MassGroup={
  "data": [
    {
      "type": "user",
      "id": "5629049"
    },
     {
      "type": "user",
      "id": "5629048"
    },
     {
      "type": "user",
      "id": "5629047"
    },
     {
      "type": "user",
      "id": "5629046"
    },
     {
      "type": "user",
      "id": "5629045"
    },
     {
      "type": "user",
      "id": "5629044"
    },
     {
      "type": "user",
      "id": "5629043"
    },
     {
      "type": "user",
      "id": "5629042"
    },
     {
      "type": "user",
      "id": "5629041"
    },
     {
      "type": "user",
      "id": "5629040"
    }
  ]
}

DeleteGroup={
  "data": [
    {
      "type": "user",
      "id": "5629038"
    }
  ]
}



def delete_request_payload(func):
    global l
    global data
    global cred
    @wraps(func)
    def wrapper(*args):
        str1="https://captivateprimestage1.adobe.com"+"/primeapi/v2/"+str(args[0])
        print(str1)
        Access_Token = get_New_Token("https://captivateprimestage1.adobe.com/",cred)
        hdr = {"Authorization": "oauth " + str(Access_Token["access_token"]),"Content-Type": "application/vnd.api+json","Accept": "application/vnd.api+json"}
        res = delete(str1,headers=hdr,data=args[1])
        print(res)
        return func(args[0],args[1],res.status_code)
    return wrapper


def post_request_payload(func):
    global cred
    global l
    global data
    @wraps(func)
    def wrapper(*args):
        str1="https://captivateprimestage1.adobe.com"+"/primeapi/v2/"+str(args[0])
        Access_Token = get_New_Token("https://captivateprimestage1.adobe.com/",cred)
        hdr = {"Authorization": "oauth " + str(Access_Token["access_token"]),"Content-Type": "application/vnd.api+json","Accept": "application/vnd.api+json"}
        res = post(str1,params=data,headers=hdr,data=args[1])
        print(res)
        return func(args[0],args[1],res.status_code)
    return wrapper
###############################################  WRAPPER FUNCTIONS ##############################################################

@post_request_payload
def post_request_add_user_usergroup(*args):
	return args[2]


@delete_request_payload
def delete_user_group(*args):
	return args[2]


################################################# TEST CASE VALIDATION ##########################################################

@Report_generate
def  post_request_adduser_UG(Testcase,usergroupid):
	str1="userGroups/"+str(usergroupid)+"/users"
	res=post_request_add_user_usergroup(str1,json.dumps(UserGroup))
	if res==204:
		return True
	else:
		return False

@Report_generate
def delete_userfrom_group(Testcase,usergroupid):
	str1="userGroups/"+str(usergroupid)+"/users"
	res=delete_user_group(str1,json.dumps(UserGroup))
	if res==204:
		return True
	else:
		return False

############################################## TEST CASE EXECUTE ###############################################################

if __name__=="__main__":
	Auto_init("User_group.csv")
	post_request_adduser_UG("Verify adding user to usergroup",597591)
	sleep(2)
	delete_userfrom_group("Delete the user from the usergroup",597591)
	post_request_adduser_UG("Add 10 users to a user group",597608)
	delete_userfrom_group("Delete 10 users from user group",597608)
	Auto_close()
    

