from utility import *

#ltautomation@gmail.com

BASE_URL="https://captivateprimestage1.adobe.com/primeapi/v1/learner-transcripts"


# get request decorator
def get_request_LT(func):
    global cred
    global l
    global data
    global BASE_URL
    global token_url
    def wrapper(*args):
        url=BASE_URL
        Access_Token=get_New_Token(token_url,cred)
        hdr={"Authorization":"oauth "+Access_Token["access_token"]}
        print(url)
        print(data)
        res=get(url,params=data,headers=hdr)
        return func(res.json(),res.status_code)
    return wrapper


#################################### WRAPPER FUNCTION #############################################################################

@get_request_LT
def get_LT_COURSE_response_code(*args):
   return args[1]


@get_request_LT
def get_LT_LP_response_code(*args):
   return args[1]


@get_request_LT
def get_LT_CER_response_code(*args):
   return args[1]


@get_request_LT
def get_LT_COURSE_response_body(*args):
   return args[0]



@get_request_LT
def get_LT_LP_response_body(*args):
   return args[0]



@get_request_LT
def get_LT_CER_response_body(*args):
   return args[0]

##########################################  VALIDATION FUNCTION COURSE ################################################################
def get_LT_course_response():
   try:
    global data
    data.clear()
    data["lo_type"]="Course"
    data["page[offset]"]=0
    data["page[limit]"]=100
    res=get_LT_COURSE_response_body()
    return res
   except Exception as e:
      return False

@Report_generate
def  test_course_completion_status(Testcase,completion_status,userid,courseid,res):
   try:
    if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["status"]==completion_status:
      return True
    else:
      return False
   except Exception as e:
      return False


@Report_generate
def  test_course_progress_status(Testcase,progress_status,userid,courseid,res):
   try:
    if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["progress"]==progress_status:
      return True
    else:
      return False
   except Exception as e:
      return False


@Report_generate
def  test_course_grade_status(Testcase,grade_status,userid,courseid,res):
   try:
    if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["grade"]==grade_status:
      return True
    else:
      return False
   except Exception as e:
      return False


@Report_generate
def  test_course_rawscore_value(Testcase,raw_score,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["scoreRaw"] == raw_score:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_highestscore_value(Testcase,highest_score,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["highestScoreRaw"] == highest_score:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_maxscore_status(Testcase,max_score,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["scoreMax"] == max_score:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_instance_value(Testcase,instance_val,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["instance"] == instance_val:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_datestarted_status(Testcase,date_started,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["dateStarted"] == date_started:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_datecompletion_status(Testcase,date_completed,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["dateCompleted"] == date_completed:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_dateenrolled_status(Testcase,date_enrolled,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["dateEnrolled"] == date_enrolled:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_learningPlan_value(Testcase,learning_plan,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["learningPlanName"] == learning_plan:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_course_selectionCriteria_value(Testcase,selection_criteria,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["selectionCriteria"] == selection_criteria:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_course_deadline_value(Testcase,deadline,userid,courseid,res):
   try:
      if res["data"]["userCourseDetails"][str(userid)][str(courseid)]["deadline"] == deadline:
         return True
      else:
         return False
   except Exception as  e:
      return False


@Report_generate
def test_coursemodule_progress_value(Testcase,progress,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["progress"] == progress:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def   test_coursemodule_grade_value(Testcase,grade,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["grade"] == grade:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_rawscore_value(Testcase,rawscore,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["scoreRaw"] == rawscore:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_highestscore_value(Testcase,hscore,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["highestScoreRaw"] == hscore:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_scoremax_value(Testcase,scoremax,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["scoreMax"] == scoremax:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_attempt_value(Testcase,attempt,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["attempts"] == attempt:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_maxattempt_value(Testcase,maxattempt,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["maxAttempts"] == maxattempt:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_coursemodule_completionstatus_value(Testcase,compstatus,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["status"] == compstatus:
         return True
      else:
         return False
   except Exception as e:
      return False



@Report_generate
def  test_coursemodule_selectioncriteria_value(Testcase,selectcriteria,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["selectionCriteria"] == selectcriteria:
         return True
      else:
         return False
   except Exception as e:
      return False



@Report_generate
def  test_coursemodule_datecomplated_value(Testcase,datecompleted,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][
         "dateCompleted"] == datecompleted:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_coursemodule_datestarted_value(Testcase,datestarted,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["dateStarted"] == datestarted:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_coursemodule_deliverytype_value(Testcase,deliverytype,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["deliveryType"] == deliverytype:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_version_value(Testcase,version,userid,courseid,moduleid,res):
   try:
      if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)]["version"] == version:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_courseModuleDetail_value(Testcase,res,courseid,*moduleids):
   try:
      for i in moduleids:
         if i not in res["data"]["courseModuleDetails"][str(courseid)]:
            return False
      return True
   except Exception as e:
      return False
   
     

@Report_generate
def  test_userDetail_name_value(Testcase,userid,name,res):
   try:
      if res["data"]["userDetails"][str(userid)]["name"] == name:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_userDetail_email_value(Testcase,userid,email,res):
   try:
      if res["data"]["userDetails"][str(userid)]["email"] == email:
         return True
      else:
         return False
   except Exception as e:
      return False

@Report_generate
def  test_coursemodule_adobeid_value(Testcase,userid,adobeid,res):
   try:
      if res["data"]["userDetails"][str(userid)]["adobeId"] == adobeid:
         return True
      else:
         return False
   except Exception as e:
      return False


@Report_generate
def  test_coursemodule_uuid_value(Testcase,userid,uuid,res):
   try:
      if res["data"]["userDetails"][str(userid)]["userUniqueId"] == uuid:
         return True
      else:
         return False
   except Exception as e:
      return False


############################################# VALIDATION  FUNCTION COURSE MODULE ##############################################
if __name__=="__main__":
   Auto_init("LT_test.csv")
   Env_init("699f114f-6737-4361-928a-9a97afadea1f","60fa9c9c-92b9-4148-b0f6-35a6da8733ea","a11107402559517e39ad9701ee317f00")
   res=get_LT_course_response()
   ########################################### Course #############################################################
   test_course_completion_status("Test the completion status of the course","Completed",5641188,1992059,res)
   test_course_progress_status("Test the inprogress status of the course",100,5641188,1992059,res)
   test_course_grade_status("Test the course grade value of the course","Pass",5641188,1992059,res)
   test_course_rawscore_value("Test the raw score value for the course",60,5641188,1992059,res)
   test_course_highestscore_value("Test the highest score value for the course",80,5641188,1992059,res)
   test_course_maxscore_status("Test the max score value for the course",80,5641188,1992059,res)
   test_course_instance_value("Test the course instance id of the course","NEW INSTANCE",5641188,1992061,res)
   test_course_datestarted_status("Test the datestarted value for the course","2019-06-06T14:37:00.000Z",5641188,1992059,res)
   test_course_datecompletion_status("Test the datecompletion status for the course","2019-06-06T14:41:00.000Z",5641188,1992059,res)
   test_course_dateenrolled_status("Test the dateenrolled status of the course","2019-06-06T14:36:00.000Z",5641188,1992059,res)
   #test_course_learningPlan_value("Test the learning plan associated with the course",learning_plan,5641188,courseid,res)
   test_course_selectionCriteria_value("Test the selection criteria associated with the course","self",5641188,1992059,res)
   test_course_deadline_value("Test the deadline asociated with the course","2023-06-21T18:29:59.000Z",5641188,1992061,res)
   # ########################################## Course Module ######################################################
   test_coursemodule_progress_value("Test the in progress value of the course module",100,5641188,1992059,2626114,res)
   test_coursemodule_grade_value("Test the grade value of the course module","Pass",5641188,1992059,2626115,res)
   test_coursemodule_rawscore_value("Test the rawscore value of course module",20,5641188,1992059,2626115,res)
   test_coursemodule_highestscore_value("Test the highest score value of the course module",40,5641188,1992059,2626115,res)
   test_coursemodule_scoremax_value("Test the maxscore associated with the course",40,5641188,1992059,2626115,res)
   test_coursemodule_attempt_value("Test the no of attempts consumed ","3",5641188,1992059,2626114,res)
   test_coursemodule_maxattempt_value("Test the maxattempt associated with the course","8",5641188,1992061,2626118,res)
   test_coursemodule_completionstatus_value("Test the course module completion status","Completed",5641188,1992059,2626114,res)
   test_coursemodule_selectioncriteria_value("Test the selection criteria associated with the course","self",5641188,1992059,2626114,res)
   test_coursemodule_datecomplated_value("Test the date associated with module complaetion","2019-06-06T14:41:05.000Z",5641188,1992059,2626114,res)
   test_coursemodule_datestarted_value("Test the datestarted field of the course module","2019-06-06T14:40:41.000Z",5641188,1992059,2626114,res)
   test_coursemodule_deliverytype_value("Test the delivery type associated with the module","ELEARNING",5641188,1992059,2626114,res)
   test_coursemodule_version_value("Test the module version associated with the module","1",5641188,1992059,2626114,res)
   test_courseModuleDetail_value("Test the modules associated with the course",res,1992059,2626114,2626115)
   ######################################## User Detail #########################################################
   test_userDetail_name_value("Test the username associated with the user",5641188,"Lt Automation",res)
   test_userDetail_email_value("Test the email associated with the user",5641188,"ltautomation@gmail.com",res)
   test_coursemodule_adobeid_value("Test the adobe id associated with the user",5641188,"ltautomation@gmail.com",res)
   #test_coursemodule_uuid_value("Test the uuid associated with the user",userid,uuid,res)
   Auto_close()





















