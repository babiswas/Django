from utility import *
from time import time
import json

@get_request
def get_request(*args):
    return args[1],args[2]

def pagination(total_data,page_limit,endpoint):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[offset]"]=0
    has_next=True
    while has_next:
       url=endpoint
       res,status=get_request(url)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False              
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True

@Report_generate
def test_pagination(testcase,total_data,page_limit,endpoint):
    try:
       result=pagination(total_data,page_limit,endpoint)
       return result
    except Exception as e:
        return False
           
if __name__=="__main__":
   Auto_init("learner_pagination.csv")
   Env_init("3fc6675e-793f-489c-97af-b2500a365807","3d1fcc80-2735-44fe-9ef2-c35a698255ef","7ff60bcc868be59e73a5f5377f942b36")
   test_pagination("Verify the pagination related to badge with page limit 10",22,10,"badges")
   test_pagination("Verify the pagination related to badge with page limit 6",22,6,"badges")
   test_pagination("Verify the pagination related to badge with page limit 4",22,4,"badges")
   test_pagination("Verify the pagination related to userbadge with page limit 10",61,10,"users/5396939/userBadges")
   test_pagination("Verify the pagination related to userbadge with page limit 6",61,6,"users/5396939/userBadges")
   test_pagination("Verify the pagination related to userbadge with page limit 4",61,4,"users/5396939/userBadges")
   test_pagination("Verify the pagination related to catalogs with page limit 10",21,10,"catalogs")
   test_pagination("Verify the pagination related to catalogs with page limit 6",21,6,"catalogs")
   test_pagination("Verify the pagination related to catalogs with page limit 4",21,4,"catalogs")
   test_pagination("Verify the pagination related to userskills with page limit 10",27,10,"users/5396939/userSkills")
   test_pagination("Verify the pagination related to userskills with page limit 6",27,6,"users/5396939/userSkills")
   test_pagination("Verify the pagination related to userskills with page limit 4",27, 4, "users/5396939/userSkills")
   test_pagination("Verify the pagination related to skills with page limit 10", 25, 10, "skills")
   test_pagination("Verify the pagination related to skills with page limit 6", 25, 6, "skills")
   test_pagination("Verify the pagination related to skills with page limit 4", 25, 4, "skills")
   Auto_close()
