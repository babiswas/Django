from utility import *
from time import time
import json

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_users_uuid(testcase,uuid1,uuid2,uuid3,*args):
    data = get_data()
    data.clear()
    data["ids"] ="uuid:"+uuid1+",uuid:"+uuid2+",uuid:"+uuid3
    try:
      url="users"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      user=[]
      for obj in res["data"]:
         user.append(obj["id"])
      for i in args:
           if i not in user:
              return False
      return True
    except Exception as e:
        return False


@Report_generate
def test_users_email(testcase,email1,email2,email3,*args):
    data = get_data()
    data.clear()
    data["ids"] ="email:"+email1+",email:"+email2+",email:"+email3
    try:
      url="users"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      user=[]
      for obj in res["data"]:
         user.append(obj["id"])
      for i in args:
           if i not in user:
              return False
      return True
    except Exception as e:
        return False


@Report_generate
def test_users_id(testcase,userid1,userid2,userid3,*args):
    data = get_data()
    data.clear()
    data["ids"] =userid1+","+userid2+","+userid3
    try:
      url="users"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      user=[]
      for obj in res["data"]:
         user.append(obj["id"])
      for i in args:
           if i not in user:
              return False
      return True
    except Exception as e:
        return False


def pagination(total_data,page_limit):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[offset]"]=0
    has_next=True
    while has_next:
       url="users"
       res,status=get_request(url)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False              
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True

@Report_generate
def test_users_pagination(testcase,total_data,page_limit):
    try:
       result=pagination(total_data,page_limit)
       return result
    except Exception as e:
        return False


@Report_generate
def test_user(testcase,*args):
    data = get_data()
    data.clear()
    try:
      url="user"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      if res["data"]["id"]==args[0] and res["data"]["attributes"]["email"]==args[1] and res["data"]["attributes"]["userUniqueId"]==args[2]:
         return True
      return False
    except Exception as e:
        return False


@Report_generate
def test_user_id(testcase,userid,*args):
    data = get_data()
    data.clear()
    try:
      url="users/"+userid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      if res["data"]["id"]==args[0] and res["data"]["attributes"]["email"]==args[1] and res["data"]["attributes"]["userUniqueId"]==args[2]:
         return True
      return False
    except Exception as e:
        return False


@Report_generate
def test_user_id_include(testcase,userid,managerid):
    data = get_data()
    data.clear()
    data["include"]="manager"
    try:
      url="users/"+userid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      if res["included"][0]["id"]==managerid:
         return True
      return False
    except Exception as e:
        return False

     
           
if __name__=="__main__":
   Auto_init("Users_filter.csv")
   Env_init("769e9ae8-ffc9-4477-b5f0-01acdbbc7b07","d8d31b03-b19f-47ee-9664-844251e46a20","086c2a8de0e73584e6ec3951bf48a030")
   test_users_uuid("Filter prime users using uuid","DDDD_DDDD_EEEE2","DDDD_DDDD_EEEE1","DDDD_DDDD_EEEE","7581184","7581183","7581182")
   Env_init("6e2ecee3-301c-4257-914c-2601ab508e06","673815e3-0753-4aad-992f-3c68d159c59a","16ea3d944c0c8a290d4cdf774880d59a")
   test_users_id("Filter prime users using prime id","5396947","5396944","5396943","5396947","5396944","5396943")
   test_users_email("Filter prime users using email","bapan@gmail.com","bapan1@gmail.com","bapan6@gmail.com","5396947","5396944","5396943")
   test_users_pagination("Test the pagination for GET users page limit 10",56,10)
   test_users_pagination("Test the pagination for GET users page limit 5",56,5)
   test_users_pagination("Test the pagination for GET users page limit 3",56,3)
   test_user("Test the request GET user","5396939","bapan1690814+9090@gmail.com","BOLO_BOLO_BOLO")
   #test_user_id("Test the user GET user by id validate email,uuid,userid,manager","5407403","bapan1690814+30021@gmail.com","A_A_A_A_21")
   test_user_id_include("Test the GET user by id include=manager","5407403","5396939")
   Auto_close()
