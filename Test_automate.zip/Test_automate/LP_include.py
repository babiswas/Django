from utility import *

@get_request
def get_lo(*args):
    return args[1]

@Report_generate
def test_course_include_instanceloresourceresource(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    data["ids"] = str(course_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False





if __name__=="__main__":
    Auto_init("LP_include.csv")
    Env_init("e683c33a-dc19-4657-83c1-80c063e7f852", "c66574a7-bdae-4301-9fd8-f6b53ab7c71f","427a14964641d857c974fddfcc83e8b5")
    Auto_close()
