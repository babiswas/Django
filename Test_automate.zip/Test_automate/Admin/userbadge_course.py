from utility import *
from time import time
import json

#bapan12q@gmail.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test__usergroup_Author_catalog(testcase,catalogid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["catalogId"] = catalogid
    data["page[limit]"]=10
    data["page[offset]"]=0
    try:
      url="userGroups"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       
    except Exception as e:
        return False


@Report_generate
def test__usergroup_IA_catalog(testcase,catalogid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["catalogId"] = catalogid
    data["page[limit]"]=10
    data["page[offset]"]=0
    try:
      url="userGroups"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       
    except Exception as e:
        return False



@Report_generate
def test__usergroup_catalog(testcase,catalogid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["catalogId"] = catalogid
    data["page[limit]"]=10
    data["page[offset]"]=0
    try:
      url="userGroups"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       
    except Exception as e:
        return False




if __name__=="__main__":
   Auto_init("usergroup_catalog.csv")
   Env_init("9b7dddab-0ec6-432c-9c66-e5dfdd063001","30e8e21f-17b2-4fd4-9950-f31051caa152","e989f76647a1d0fbe76d9a37c4793829")
   Auto_close()
