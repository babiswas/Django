from utility import *
from time import time
import json

@get_request
def get_catalog_lo(*args):
    return args[1]

@get_request
def get_enrollment_id(*args):
    return args[1]


@Report_generate
def test_lo_state_LP(testcase,state,count):
    enrollment=[]
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="learningProgram"
       data["filter.learnerState"]=state
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break 
       for id in  enrollment: 
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]!=state.upper():
              return False
       if len(enrollment)!=count:
           return False
       return True           
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_LP(testcase,state,catalog,count):
    enrollment=[]
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="learningProgram"
       data["filter.learnerState"]=state
       data["filter.catalogIds"]=catalog
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             if "enrollment" not in obj["relationships"].keys():
                enrollment.append(obj["id"])
             else:
                return False
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break 
       if len(enrollment)!=count:
           return False
       return True           
    except Exception as e:
       return False

if __name__=="__main__":
   Auto_init("lpstate.csv")
   Env_init("2aa97068-92dc-4741-8c57-ce44e777eba7","afd4cfd3-ae00-45b2-bb48-1ded68d102e3","3901162ffb2c30680433666086f82c82")
   test_lo_state_LP("Test the state of the LP","completed",7)
   test_lo_catalog_LP("Test the notenrolled state of the LP","notenrolled",13478,10)
   Auto_close()
