from utility import *
from time import time
import json

#bapan12w12w@gmail.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@post_request_payload
def post_request(*args):
    return args[2],args[3]

@delete_request_parameter
def delete_request(*args):
    return args[1]

@patch_request_payload
def patch_request(*args):
    return args[2],args[3]

@post_user
def post_user_payload(*args):
    return args[2]

class Create_Board:
   def __init__(self):
      self.type="board"
      self.attributes={'description':'','name':'','postingAllowed':'','state':'','visibility':''}
      self.relationships={'skills':{'data':[{'id':'','type':'skill'}]}}

   def construct_payload(self):
       payload={'data':self.__dict__}
       return json.dumps(payload)

   def set_attributes(self,*args):
       self.attributes['description']=args[0]
       self.attributes['name']=args[1]
       self.attributes['postingAllowed']=args[2]
       self.attributes['state']=args[3]
       self.attributes['visibility']=args[4]
       return self

   def add_skill(self,id):
       self.relationships['skills']['data'].append({'id':id,'type':'skill'})
       return self

   def set_skill(self,id):
       self.relationships['skills']['data'][0]['id']=id
       return self

   def change_description(self,description):
       self.attributes['description']=description
       return self

   def change_name(self,name):
       self.attributes['name']=name
       return self

   def change_state(self,state):
       self.attributes['state']=state
       return self

   def change_visiblity(self,visibility):
       self.attributes['visibility']=visibility
       return self

   def change_postingAllowed(self,Allowed):
       self.attributes['postingAllowed']=Allowed
       return self



class Update_Board:
   def __init__(self,id):
      self.id=str(id)
      self.type="board"
      self.attributes={'description':'','name':'','postingAllowed':'','state':'','visibility':''}
      self.relationships={'skills':{'data':[{'id':'','type':'skill'}]},"createdBy":{'data':{'id':'','type':'user'}}}

   def construct_payload(self):
       payload={'data':self.__dict__}
       return json.dumps(payload)

   def set_attributes(self,*args):
       self.attributes['description']=args[0]
       self.attributes['name']=args[1]
       self.attributes['postingAllowed']=args[2]
       self.attributes['state']=args[3]
       self.attributes['visibility']=args[4]
       return self

   def add_createdby(self,userid):
       self.relationships["createdBy"]['data']['id']=str(userid)
       return self

   def add_skill(self,id):
       self.relationships['skills']['data'].append({'id':id,'type':'skill'})
       return self

   def set_skill(self,id):
       self.relationships['skills']['data'][0]['id']=id
       return self

   def change_description(self,description):
       self.attributes['description']=description
       return self

   def change_name(self,name):
       self.attributes['name']=name
       return self

   def change_state(self,state):
       self.attributes['state']=state
       return self

   def change_visiblity(self,visibility):
       self.attributes['visibility']=visibility
       return self

   def change_postingAllowed(self,Allowed):
       self.attributes['postingAllowed']=Allowed
       return self


class Moderator:
    def __init__(self,id):
        self.type = "user"
        self.id=id

    def construct_payload(self):
        body={'data':[self.__dict__]}
        return json.dumps(body)

    def add_moderators(self,*args):
        body={'data':[self.__dict__]}
        for obj in args:
           body['data'].append(obj.__dict__)
        return json.dumps(body)


class User:
    def __init__(self,id):
        self.type = "user"
        self.id=id


    def construct_payload(self):
        body={'data':[self.__dict__]}
        return json.dumps(body)

    def add_users(self,*args):
        body={'data':[self.__dict__]}
        for obj in args:
            body['data'].append(obj.__dict__)
        return json.dumps(body)
            
@Report_generate
def test_create_board(testcase,*args):
    try:
        c=Create_Board()
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5])
        payload=c.construct_payload()
        res,status=post_request("boards",payload)
        if status!=200:
            raise Exception
        try:
            board_id=res["data"]["id"]
            url="boards/"+str(board_id)
            resp,status=get_request(url)
            if status!=200:
                raise Exception
            if resp["data"]["id"]==res["data"]["id"] and resp["data"]["attributes"]["name"]==res["data"]["attributes"]["name"] and resp["data"]["attributes"]["state"]==res["data"]["attributes"]["state"] and resp["data"]["attributes"]["visibility"]==res["data"]["attributes"]["visibility"]:
                if resp["data"]["attributes"]["name"]==args[1] and resp["data"]["attributes"]["visibility"]==args[4] and resp["data"]["relationships"]["skills"]["data"][0]["id"]==args[5]:
                    return True
                else:
                    return False
            else:
                return False
        except Exception as e:
            return False
    except Exception as e:
        return False


def pagination(total_data,page_limit,endpoint):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[offset]"]=0
    has_next=True
    while has_next:
       url=endpoint
       res,status=get_request(url)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False              
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True

@Report_generate
def test_pagination(testcase,total_data,page_limit,endpoint):
    try:
       result=pagination(total_data,page_limit,endpoint)
       return result
    except Exception as e:
        return False

@Report_generate
def test_delete_board(testcase,id):
    try:
       url="boards/"+str(id)
       status=delete_request(url)
       if status!=204:
          return False
       resp,status=get_request(url)
       if status!=200:
          return False
    except Exception as e:
        return False
    try:
       if resp["data"]["attributes"]["state"]=="DELETED":
          return True
       else:
          return False
    except Exception as e:
        return False


@Report_generate
def test_visibility_board(testcase,id,visibility):
    try:
       url="boards/"+str(id)
       resp,status=get_request(url)
       if status!=200:
          return False
    except Exception as e:
        return False
    try:
       if resp["data"]["attributes"]["visibility"]==visibility:
          return True
       else:
          return False
    except Exception as e:
        return False


@Report_generate
def test_moderators_board(testcase,id,*args):
    try:
       url="boards/"+str(id)+"/moderators"
       res,status=get_request(url)
       if status!=200:
          return False
    except Exception as e:
        return False
    try:
       users=[]
       for obj in res["data"]:
         users.append(obj["id"])
       for obj in args:
         if obj not in users:
             return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_associate_moderators_board(testcase,userid,*args):
    try:
        c=Create_Board()
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5])
        payload=c.construct_payload()
        res,status=post_request("boards",payload)
        if status!=200:
           raise Exception
        board_id=res["data"]["id"]
        url="boards/"+str(board_id)+"/moderators"
        moderator=Moderator(userid)
        payload=moderator.construct_payload()
        status_moderator=post_user_payload(url,payload)
        if status_moderator!=204:
           raise Exception
        res_get,status_get=get_request(url)
        if status_get!=200:
          raise Exception
    except Exception as e:
        return False
    try:
       if res_get["data"][1]["id"]==userid:
          return True
       else:
          return False
    except Exception as e:
        return False


@Report_generate
def test_associate_users_private_board(testcase,userid,*args):
    try:
        c=Create_Board()
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5])
        payload=c.construct_payload()
        res,status=post_request("boards",payload)
        if status!=200:
           raise Exception
        board_id=res["data"]["id"]
        url="boards/"+str(board_id)+"/users"
        user=User(userid)
        payload=user.construct_payload()
        status_user=post_user_payload(url,payload)
        if status_user!=204:
           raise Exception
        res_get,status_get=get_request(url)
        if status_get!=200:
          raise Exception
    except Exception as e:
        return False
    try:
       if res_get["data"][1]["id"]==userid:
          return True
       else:
          return False
    except Exception as e:
        return False

@Report_generate
def test_users_private_board(testcase,board_id,*args):
    try:
       users=[]
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[offset]"]=0
       has_next=True
       url="boards/"+str(board_id)+"/users"
       while has_next:
          res,status=get_request(url)
          if status!=200:
             raise Exception
          if "links" in res:
             if "next" in res["links"]:
                offset=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
                data["page[offset]"]=offset
          for obj in res["data"]:
             users.append(obj["id"])
          if "next" not in res["links"]:
              break
    except Exception as e:
       return False
    try:
        for obj in args:
            if obj not in users:
               return False
        if len(users)!=len(args):
               return False
        return True
    except Exception as e:
       return False

@Report_generate
def test_moderators_board(testcase,board_id,*args):
    try:
       users=[]
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[offset]"]=0
       has_next=True
       url="boards/"+str(board_id)+"/moderators"
       while has_next:
          res,status=get_request(url)
          if status!=200:
             raise Exception
          if "links" in res:
             if "next" in res["links"]:
                offset=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
                data["page[offset]"]=offset
          for obj in res["data"]:
             users.append(obj["id"])
          if "next" not in res["links"]:
              break
    except Exception as e:
       return False
    try:
        for obj in args:
            if obj not in users:
               return False
        if len(users)!=len(args):
               return False
        return True
    except Exception as e:
       return False


@Report_generate
def test_update_board(testcase,id,*args):
    try:
        c=Update_Board(id)
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5]).add_createdby(args[6])
        payload=c.construct_payload()
        url="boards/"+str(id)
        res,status=patch_request(url,payload)
        if status!=200:
           raise Exception
        res_get,status_get=get_request(url)
        if status_get!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if res_get["data"]["attributes"]["description"]==args[0] and res_get["data"]["attributes"]["name"]==args[1] and res_get["data"]["attributes"]["postingAllowed"]==args[2] and res_get["data"]["attributes"]["state"]==args[3] and res_get["data"]["attributes"]["visibility"]==args[4]:
           return True
        else:
           return False
    except Exception as e:
        return False


@Report_generate
def test_update_board_skill(testcase,id,skillid,*args):
    try:
        c=Update_Board(id)
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(skillid).add_createdby(args[5])
        payload=c.construct_payload()
        url="boards/"+str(id)
        res,status=patch_request(url,payload)
        if status!=200:
           raise Exception
        res_get,status_get=get_request(url)
        if status_get!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if res_get["data"]["relationships"]["skills"]["data"][0]["id"]==str(skillid):
           return True
        else:
           return False
    except Exception as e:
        return False


@Report_generate
def test_update_board_visiblity(testcase,id,visibility,*args):
    try:
        c=Update_Board(id)
        c.set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5]).add_createdby(args[6]).change_visiblity(visibility)
        payload=c.construct_payload()
        url="boards/"+str(id)
        res,status=patch_request(url,payload)
        if status!=200:
           raise Exception
        res_get,status_get=get_request(url)
        if status_get!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        if res_get["data"]["attributes"]["visibility"]==visibility:
           return True
        else:
           return False
    except Exception as e:
        return False



@Report_generate
def test_create_delete_board(testcase,*args):
    try:
        c = Create_Board()
        c.set_attributes(args[0], args[1], args[2], args[3], args[4]).set_skill(args[5])
        payload = c.construct_payload()
        res, status = post_request("boards", payload)
        if status!=200:
           raise Exception
        url = "boards/" + res["data"]["id"]
        status_get=delete_request(url)
        if status_get!=204:
           raise Exception
        res,status=get_request(url)
        if status!=200:
            return False
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["state"]=="DELETED":
           return True
        else:
           return False
    except Exception as e:
        return False


@Report_generate
def test_create_board_multiple_skill(testcase,*args):
    skill=[]
    try:
        c=Create_Board()
        c.set_attributes(args[0],args[1],args[2],args[3],args[4])
        c.relationships["skills"]["data"].clear()
        for index,obj in enumerate(args):
            if index>4:
                c.add_skill(obj)
                skill.append(obj)
        payload=c.construct_payload()
        res,status=post_request("boards",payload)
        if status!=200:
            raise Exception
        try:
            skill_obtained=[]
            board_id=res["data"]["id"]
            url="boards/"+str(board_id)
            resp,status=get_request(url)
            if status!=200:
                raise Exception
            if resp["data"]["id"]==res["data"]["id"]:
               for obj in resp["data"]["relationships"]["skills"]["data"]:
                   skill_obtained.append(obj["id"])
               for i in skill:
                   if i not in skill_obtained:
                       return False
               return True
            else:
                return False
        except Exception as e:
            return False
    except Exception as e:
        return False
           
if __name__=="__main__":
   Auto_init("Social_board.csv")
   Env_init("90c160b4-f3d0-49b7-b5e8-c194189ef4dc","f6830823-1391-42e7-9f79-85313b6588a0","c1823c5bccee2a5bf197863545ef0aae")
   test_create_board("Verify if a learner can create public board which is ACTIVE","My board description","My Board",True,"ACTIVE","PUBLIC","46242")
   test_create_board("Verify if a learner can create private board which is ACTIVE","My board description1","My Board1",True,"ACTIVE","PRIVATE","46242")
   test_update_board_skill("Update the skill associated with board and verify using GET",1121,"46239","My board description","My Board",True,"ACTIVE","PUBLIC","7581672")
   test_update_board_skill("Set the skill associated with board previous value and verify using GET", 1121,"46242","My board description", "My Board", True, "ACTIVE", "PUBLIC","7581672")
   test_update_board("Change the description,name of the board and verify using GET",1121,"My board description 100", "My Board 100",True, "ACTIVE", "PUBLIC","46242","7581672")
   test_update_board("Reset the description,name to previous value of the board and verify using GET",1121,"My board description","My Board", True, "ACTIVE", "PUBLIC","46242","7581672")
   test_update_board_visiblity("Update the visibility of a board  from public to private",1133,"PRIVATE","My board description","My Board", True, "ACTIVE", "PUBLIC","46242","7581672")
   test_update_board_visiblity("Update the visibility of a board  from private to public",1133,"PUBLIC","My board description","My Board", True, "ACTIVE", "PUBLIC","46242","7581672")
   test_associate_moderators_board("Verify if a moderator can be associated with a board","7581691","My board description","My Board", True, "ACTIVE", "PUBLIC","46242")
   test_create_delete_board("Create a board and delete the same verify the state using GET","My board description","My Board", True, "ACTIVE", "PUBLIC","46242")
   test_associate_users_private_board("Associate a user to a private board","7581693","My board description","My Board", True, "ACTIVE", "PRIVATE","46242")
   test_users_private_board("Verify all the users associated with private board is visible through api",1233,"7581691","7581692","7581695","7581699")
   test_update_board_visiblity("Update the visibility of a public board to Restricted",1261,"RESTRICTED","My board description","My Board",True,"ACTIVE","PUBLIC","46242","7581672")
   test_update_board_visiblity("Update the visibility of a Restricted board to Public", 1261,"PUBLIC","My board description", "My Board", True, "ACTIVE", "PUBLIC", "46242", "7581672")
   test_create_board("Verify if a user can create restricted board","My board description","My Board",True,"ACTIVE","RESTRICTED","46242")
   test_update_board_visiblity("Update the visibility of a Restricted board to Public",1281, "PUBLIC","My board description", "My Board", True, "ACTIVE", "RESTRICTED", "46242", "7581672")
   test_update_board_visiblity("Update the visibility of a Public board to Restricted", 1281, "RESTRICTED","My board description", "My Board", True, "ACTIVE", "PUBLIC", "46242", "7581672")
   test_create_board_multiple_skill("Verify that an user can create a board with multiple skill","My board description","My Board",True,"ACTIVE","PUBLIC","46242","46239")
   Auto_close()
