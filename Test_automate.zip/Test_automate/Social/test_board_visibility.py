from utility import *
from test_board import *
from time import time
import json

#bapan12w12w@adobe.com
#Learner#12

@Report_generate
def test_user_visible_board(testcase,boardid,httpcode,*args):
    try:
       url="boards/"+str(boardid)
       res,status=get_request(url)
       if status!=httpcode:
          raise Exception
       if httpcode==400 and status==httpcode:
           return True
    except Exception as e:
       return False
    try:
       if res["data"]["id"]==str(boardid):
          if res["data"]["attributes"]["name"]==str(args[0]):
              return True
          else:
              return False
       else:
           return False           
    except Exception as e:
       return False

@Report_generate
def test_user_edit_board(testcase,boardid,httpcode,*args):
    try:
        url="boards/"+str(boardid)
        board=Update_Board(boardid).set_attributes(args[0],args[1],args[2],args[3],args[4]).set_skill(args[5]).add_createdby(args[6])
        payload=board.construct_payload()
        res,status=patch_request(url,payload)
        if status!=httpcode:
            raise Exception
        if httpcode==401 and status==httpcode:
            return True
        resp,status_get=get_request(url)
        if status_get!=200:
            raise Exception
    except Exception as e:
         return False
    try:
       if resp["data"]["attributes"]["name"]==res["data"]["attributes"]["name"]:
           return True
       else:
           return False
    except Exception as e:
         return False

           
if __name__=="__main__":
   Auto_init("board_edit.csv")
   Env_init("90c160b4-f3d0-49b7-b5e8-c194189ef4dc","f6830823-1391-42e7-9f79-85313b6588a0","c1823c5bccee2a5bf197863545ef0aae")
   test_user_visible_board("Verify user can view the public board",1315,200,"FRGGGGGG")
   test_user_visible_board("Verify user can view the private board",1316,200,"DEFFGGGGG")
   test_user_visible_board("Verify user can view the restricted board",1317,200,"DERRRR DUUUUUU  GTTTT")
   test_user_edit_board("Verify user can update the public board",1315,200,"DESSSSSS 10","FRGGGGGG 10",True,"ACTIVE","PUBLIC","46239","7581672")
   test_user_edit_board("Verify user can update the public board", 1315, 200, "DESSSSSS", "FRGGGGGG", True,"ACTIVE", "PUBLIC", "46239", "7581672")
   test_user_edit_board("Verify user can update the private board ",1316,200,"DEGGGGGGGG DERRRRR 10","DEFFGGGGG 10",True,"ACTIVE","PRIVATE","46239","7581672")
   test_user_edit_board("Verify user can update the private board ",1316, 200, "DEGGGGGGGG DERRRRR","DEFFGGGGG",True,"ACTIVE","PRIVATE","46239","7581672")
   test_user_edit_board("Verify user can update the restricted board",1317,200,"DESSSSSS 10","DERRRR DUUUUUU  GTTTT 10",True,"ACTIVE","RESTRICTED","46239","7581672")
   test_user_edit_board("Verify user can update the restricted board", 1317, 200, "DESSSSSS","DERRRR DUUUUUU  GTTTT", True,"ACTIVE","RESTRICTED","46239","7581672")
   Env_init("2620e761-27da-421f-8c3a-7cbaf79a283a","f2f020f8-1791-40ae-b056-a610a5298adf","ba3f185b13ce4997f05a36700ada88d8")
   test_user_visible_board("Verify user can view the public board and moderator", 1315, 200,"FRGGGGGG")
   test_user_visible_board("Verify user who is  part of private board can view the private board", 1316, 200, "DEFFGGGGG")
   test_user_visible_board("Verify user can view the restricted board",1317, 200, "DERRRR DUUUUUU  GTTTT")
   test_user_edit_board("Verify user can't  update the public board if he is not authorized", 1315,401, "DESSSSSS 10", "FRGGGGGG 10", True,"ACTIVE", "PUBLIC", "46239", "7581672")
   test_user_edit_board("Verify user can't  update the public board if he is not authorized", 1315,401, "DESSSSSS", "FRGGGGGG", True, "ACTIVE","PUBLIC", "46239", "7581672")
   test_user_edit_board("Verify user can't update the private board if he is not authorized", 1316,401, "DEGGGGGGGG DERRRRR 10", "DEFFGGGGG 10",True, "ACTIVE", "PRIVATE", "46239", "7581672")
   test_user_edit_board("Verify user can update the private board if he is not authorized", 1316,401, "DEGGGGGGGG DERRRRR", "DEFFGGGGG", True,"ACTIVE", "PRIVATE", "46239", "7581672")
   test_user_edit_board("Verify user can update the restricted board if he is not authorized", 1317,401, "DESSSSSS 10","DERRRR DUUUUUU  GTTTT 10", True, "ACTIVE", "RESTRICTED", "46239", "7581672")
   test_user_edit_board("Verify user can update the restricted board if he is not authorized", 1317,401, "DESSSSSS", "DERRRR DUUUUUU  GTTTT",True, "ACTIVE", "RESTRICTED", "46239", "7581672")
   Env_init("fb53f0b2-7106-4dff-8a8d-1e5d01f6cd1e", "1b6b57e5-bd58-4947-94e6-55bcea1feefa","e5cbd4efe67bf6e51d53b885c3439e30")
   test_user_visible_board("Verify user can view the public board and moderator", 1315, 200, "FRGGGGGG")
   test_user_visible_board("Verify user who is not part of private board can't view the private board", 1316,401, "DEFFGGGGG")
   test_user_visible_board("Verify user can view the restricted board",1317, 200,"DERRRR DUUUUUU  GTTTT")
   Auto_close()
