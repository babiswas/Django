from utility import *
from time import time
import json

# bapan12w12w@gmail.com
#baps1@baps.com
# Learner#12

@get_request
def get_request(*args):
    return args[1], args[2]


@post_request_payload
def post_request(*args):
    return args[2], args[3]


@delete_request_parameter
def delete_request(*args):
    return args[1]


@patch_request_payload
def patch_request(*args):
    return args[2], args[3]


@post_user
def post_user_payload(*args):
    return args[2]

class Post:
    def __init__(self,boardid):
        self.type="post"
        self.attributes={"postingType":"DEFAULT","state":"ACTIVE","text":"text"}
        self.relationships={"parent":{"data":{"id":str(boardid),"type":"board"}}}

    def construct_payload(self):
        payload={'data':self.__dict__}
        return json.dumps(payload)

    def set_text(self,text):
        self.attributes["text"]=text
        return self

    def set_boardid(self,boardid):
        self.relationships["parent"]["data"]["id"]=boardid
        return self

@Report_generate
def test_moderator_board_post(testcase,boardid,*args):
    try:
        payload=Post(boardid).set_text(args[0]).construct_payload()
        url="boards/"+str(boardid)+"/posts"
        res,status=post_request(url,payload)
        if status!=200:
            raise Exception
        data=get_data()
        data.clear()
        data["sort"]="-dateCreated"
        data["page[limit]"]=1
        res_get,status_get=get_request(url)
        if status_get!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res_get["data"][0]["id"]==res["data"]["id"] and res_get["data"][0]["attributes"]["text"]==res["data"]["attributes"]["text"]:
            return True
        else:
            return False
    except Exception as e:
        return False

@Report_generate
def test_user_board_public_post(testcase,boardid,*args):
    try:
        payload = Post(boardid).set_text(args[0]).construct_payload()
        url = "boards/" + str(boardid) + "/posts"
        res, status = post_request(url, payload)
        if status != 200:
            raise Exception
        data = get_data()
        data.clear()
        data["sort"] = "-dateCreated"
        data["page[limit]"] = 1
        res_get, status_get = get_request(url)
        if status_get != 200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res_get["data"][0]["id"]==res["data"]["id"] and res_get["data"][0]["attributes"]["text"]==res["data"]["attributes"]["text"]:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_user_board_restricted_post(testcase,boardid,*args):
    try:
        payload = Post(boardid).set_text(args[0]).construct_payload()
        url = "boards/" + str(boardid) + "/posts"
        res, status = post_request(url, payload)
        if status!=401:
            return False
        else:
            return True
    except Exception as e:
        return False


@Report_generate
def test_not_user_board_private_post(testcase,boardid,*args):
    try:
        payload = Post(boardid).set_text(args[0]).construct_payload()
        url = "boards/" + str(boardid) + "/posts"
        res, status = post_request(url, payload)
        if status!=401:
            return False
        else:
            return True
    except Exception as e:
        return False

@Report_generate
def test_user_board_private_post(testcase,boardid,*args):
    try:
        payload = Post(boardid).set_text(args[0]).construct_payload()
        url = "boards/" + str(boardid) + "/posts"
        res, status = post_request(url, payload)
        if status != 200:
            raise Exception
        data = get_data()
        data.clear()
        data["sort"] = "-dateCreated"
        data["page[limit]"] = 1
        res_get, status_get = get_request(url)
        if status_get != 200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res_get["data"][0]["id"]==res["data"]["id"] and res_get["data"][0]["attributes"]["text"]==res["data"]["attributes"]["text"]:
            return True
        else:
            return False
    except Exception as e:
        return False



if __name__ == "__main__":
    Auto_init("Board_posts.csv")
    Env_init("90c160b4-f3d0-49b7-b5e8-c194189ef4dc", "f6830823-1391-42e7-9f79-85313b6588a0","c1823c5bccee2a5bf197863545ef0aae")
    test_moderator_board_post("Verify if a moderator can post on public board",1288,"Moderator Moderator")
    test_moderator_board_post("Verify if a moderator can post on private board",1289,"Moderator Moderator")
    test_moderator_board_post("Verify if a moderator can post on restricted board",1290,"Moderator Moderator")
    Env_init("2620e761-27da-421f-8c3a-7cbaf79a283a","f2f020f8-1791-40ae-b056-a610a5298adf","ba3f185b13ce4997f05a36700ada88d8")
    test_user_board_public_post("Verify if an user can post on public board",1288,"User User")
    test_user_board_private_post("Verify if an user can post on private board", 1289, "User User")
    test_user_board_restricted_post("Verify that no post should get created by user whos is not moderator on restricted board", 1290, "User User")
    Env_init("fb53f0b2-7106-4dff-8a8d-1e5d01f6cd1e", "1b6b57e5-bd58-4947-94e6-55bcea1feefa","e5cbd4efe67bf6e51d53b885c3439e30")
    test_not_user_board_private_post("Verify that a user not associate with private board can't create post on the board",1289,"Not Private")
    Auto_close()
