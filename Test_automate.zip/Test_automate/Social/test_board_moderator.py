from utility import *
from test_board import *
from time import time
import json


# bapan12w12w@adobe.com
# Learner#12

@Report_generate
def test_user_visible_board(testcase, boardid, httpcode, *args):
    try:
        url = "boards/" + str(boardid)
        res, status = get_request(url)
        if status != httpcode:
            raise Exception
        if httpcode == 400 and status == httpcode:
            return True
    except Exception as e:
        return False
    try:
        if res["data"]["id"] == str(boardid):
            if res["data"]["attributes"]["name"] == str(args[0]):
                return True
            else:
                return False
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_user_edit_board(testcase, boardid, httpcode, *args):
    try:
        url = "boards/" + str(boardid)
        board = Update_Board(boardid).set_attributes(args[0], args[1], args[2], args[3], args[4]).set_skill(
            args[5]).add_createdby(args[6])
        payload = board.construct_payload()
        res, status = patch_request(url, payload)
        if status != httpcode:
            raise Exception
        if httpcode == 401 and status == httpcode:
            return True
        resp, status_get = get_request(url)
        if status_get != 200:
            raise Exception
    except Exception as e:
        return False
    try:
        if resp["data"]["attributes"]["name"] == res["data"]["attributes"]["name"]:
            return True
        else:
            return False
    except Exception as e:
        return False


if __name__ == "__main__":
    Auto_init("board_moderator_edit.csv")
    Env_init("2620e761-27da-421f-8c3a-7cbaf79a283a", "f2f020f8-1791-40ae-b056-a610a5298adf","ba3f185b13ce4997f05a36700ada88d8")
    test_user_edit_board("Verify if a moderator whos is not creator of the board can change board settings",1318,200,"DEDDDDDDD 10","BESDFFFFF 10",True,"ACTIVE","PUBLIC","46239","7581672")
    test_user_edit_board("Verify if a moderator whos is not creator of the board can change board settings",1318,200,"DEDDDDDDD","BESDFFFFF",True,"ACTIVE","PUBLIC","46239","7581672")
    test_user_edit_board("Verify if a moderator who is not creator of the board can change setting of private board",1319,200,"DESSSS 10","MEMMMM 10",True,"ACTIVE","PRIVATE","46239","7581672")
    test_user_edit_board("Verify if a moderator who is not creator of the board can change setting of private board",1319, 200, "DESSSS", "MEMMMM", True, "ACTIVE", "PRIVATE", "46239", "7581672")
    test_user_edit_board("Verify if a moderator who is not creator of the board can change setting of restricted board",1320, 200, "KRRRRRR 10", "DEFGHHJJJKKK 10", True, "ACTIVE", "RESTRICTED", "46239", "7581672")
    test_user_edit_board("Verify if a moderator who is not creator of the board can change setting of restricted board",1320, 200, "KRRRRRR", "DEFGHHJJJKKK", True, "ACTIVE", "RESTRICTED", "46239", "7581672")
    Auto_close()
