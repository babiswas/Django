import json
from utility import *
import sys



class Modulegrade:
   def __init__(self,userid,courseid,):
      self.type="userModuleGrade"
      self.attributes={'duration':1,'score':20,'minscore':10,'maxscore':20,'dateCompleted':'','dateSuccess':'','dateStarted':'','started':True,'completed':True,'success':True}
      self.relationships={'learner':{'data':[{'id':str(userid),'type':'user'}]},'module':{'data':[{'id':'','type':'courseModule']},'course':{'data':[{'id':str(courseid),'type':'course'}]}}

   def construct_payload(self):
      payload={'data':self.__dict__}
      return json.dumps(payload)

   def obtain_module_id(self):
      pass


if __name__=="__main__":
   module_grade=Modulegrade(
