from utility import *
from collections import defaultdict


@get_request
def get_lo(*args):
    return args[1]

@Report_generate
def test_certification_enrollment_external(Testcase,enrollment_id,state):
    req = None
    try:
        str1="enrollments/"+enrollment_id.split(':')[0]+"%3A"+enrollment_id.split(':')[1]
        req = get_lo(str1)
    except Exception as e:
        return False
    try:
        if req["data"]["attributes"]["state"]==state:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_certification_enrollment_internal(Testcase,enrollment_id,state):
    req = None
    try:
        str1="enrollments/"+enrollment_id.split(':')[0]+"%3A"+enrollment_id.split(':')[1]
        req = get_lo(str1)
    except Exception as e:
        return False
    try:
        if req["data"]["attributes"]["state"]==state:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_certificate_validity(Testcase,cert_id,validity):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                if obj["attributes"]["validity"]==validity:
                    return True
                else:
                    return False
    except Exception as e:
        return False


@Report_generate
def test_certificate_deadline(Testcase,cert_id,deadline):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                if obj["attributes"]["completionDeadline"]==deadline:
                    return True
                else:
                    return False
    except Exception as e:
        return False


@Report_generate
def test_certificate_badge(Testcase,cert_id,badge_id):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                if obj["relationships"]["badge"]["data"]["id"]==badge_id:
                    return True
                else:
                    return False
    except Exception as e:
        return False


@Report_generate
def test_certificate_sublo_order(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo=[]
    try:
        for obj in req["data"][0]["relationships"]["subLOs"]["data"]:
            sublo.append(obj["id"])
        if (sublo==list(args)) and req["data"][0]["attributes"]["isSubLoOrderEnforced"]:
            return True
        else:
            return False
    except Exception as e:
        return False

@Report_generate
def test_course_instance_enroll_certificate(Testcase,cert_id,instance_id):
    req = None
    data = get_data()
    data.clear()
    data["include"] ="subLOs"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"] and obj["id"].split(':')[0]=="course":
                if obj["relationships"]["enrollment"]["data"]["id"].split('_')[1]==instance_id:
                    return True
                else:
                    return False
    except Exception as e:
        return False


@Report_generate
def test_tags_certificate(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    tags=[]
    try:
        for tag in req["data"][0]["attributes"]["tags"]:
            tags.append(tag)
        for obj in args:
            if obj not in tags:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_subloinstance_certificate(Testcase, cert_id, *args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    subloinstance = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"].split(':')[0]=="certification":
                for object in obj["relationships"]["subLoInstances"]["data"]:
                    subloinstance.append(object["id"])
        for obj in args:
            if obj not in subloinstance:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_subloinstance_name_certificate(Testcase, cert_id, *args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.subLoInstances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    subloinstance_name = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"].split(':')[0]=="course":
                    subloinstance_name.append(obj["attributes"]["localizedMetadata"][0]["name"])
        for obj in args:
            if obj not in subloinstance_name:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_subloinstance_deadline_certificate(Testcase, cert_id, *args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.subLoInstances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    subloinstance_deadline = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"].split(':')[0]=="course":
                    subloinstance_deadline.append(obj["attributes"]["completionDeadline"])
        for obj in args:
            if obj not in subloinstance_deadline:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_subloinstance_state_certificate(Testcase, cert_id,sublo_id,state_str):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.subLoInstances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    subloinstance_state = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"]==sublo_id:
                    if obj["attributes"]["state"]==state_str:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


@Report_generate
def test_sublo_isDefault_state_certificate(Testcase, cert_id,sublo_id,isdefault):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.subLoInstances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    subloinstance_state = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"]==sublo_id:
                    if obj["attributes"]["isDefault"]==isdefault:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False


@Report_generate
def test_isflexible_state_certificate(Testcase, cert_id,sublo_id,isflexible):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.subLoInstances"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    subloinstance_state = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"]==sublo_id:
                    if obj["attributes"]["isFlexible"]==isflexible:
                        return True
                    else:
                        return False
        return False
    except Exception as e:
        return False

if __name__=="__main__":
    Auto_init("Cert_Workflow.csv")
    Env_init("fff02ce8-c039-4006-9d0b-48e15adfd6fa", "c560f429-c463-4815-a697-798f11136a77","113fb50b4260ab62b43ba94b5c3003d1")
    test_certification_enrollment_external("Test the pending approval status of the external certificate","certification:65987_99553_6530752","PENDING_APPROVAL")
    test_certification_enrollment_external("Test the completion status of the external certificate","certification:65985_99551_6530752","COMPLETED")
    test_certification_enrollment_external("Test the rejected status of the external certificate","certification:65989_99555_6530752","REJECTED")
    test_certification_enrollment_internal("Test the completed status of the internal certificate","certification:65992_99558_6530752","COMPLETED")
    test_certification_enrollment_internal("Test the started status of the internal certificate","certification:65990_99556_6530752","STARTED")
    test_certification_enrollment_internal("Test the enrollment status of the internal certificate","certification:65993_99559_6530752","ENROLLED")
    test_certificate_validity("Test the validity of the internal certificate","certification:65994","12m")
    test_certificate_deadline("Test the deadline set in the internal certificate","certification:65994","23d")
    test_certificate_badge("Test the badge associated with the certificate","certification:65994","7134")
    test_certificate_sublo_order("Test the sublo order enforced for the certificate","certification:65995","course:2021915","course:2021917","course:2021916")
    test_course_instance_enroll_certificate("Test the course instance mapping for the Certificate","certification:65999","3701297")
    test_tags_certificate("Test the tags associated with the certificate","certification:65996","BGHHHHHHH","ghhh","bccccc","bxxxxxx")
    test_subloinstance_certificate("Test the sublo instance associated with the certificate:","certification:66023","course:2021918_3701018","course:2022187_3701294")
    test_subloinstance_name_certificate("Test the sublo instance name associated with certificate","certification:66023","I  AM DEFAULT","I AM A DEFAULT")
    test_subloinstance_deadline_certificate("Test the deadline associated with the sublo instances","certification:66023","2031-11-19T18:29:59.000Z","2026-11-18T18:29:59.000Z")
    test_subloinstance_state_certificate("Test the state of the sublo instance","certification:66023","course:2022187_3701294","Active")
    test_sublo_isDefault_state_certificate("Test the isdefault state of the subloinstance","certification:66023","course:2021918_3701018",True)
    Auto_close()
