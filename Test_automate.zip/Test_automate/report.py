import os
import glob
import pandas as pd

os.chdir("./")
files=[file for file in glob.glob('*.csv')]
if 'report.csv' in files:
    files.remove('report.csv')
    os.remove('./report.csv')
report=pd.concat([pd.read_csv(f) for f in files])
report.to_csv("report.csv",index=False,encoding='utf-8-sig')
