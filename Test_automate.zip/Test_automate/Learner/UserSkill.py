from url_generator import *
from requests import get, post
import sys


class UserSkill:
    query = {"page[offset]": 0, "page[limit]": 10, "sort": "dateAchieved", "ids": '',"include":''}
    endpoint =""
    SORT = {"dateAchieved", "-dateAchieved"}
    hdr = {"Authorization": ''}
    INCLUDE=[]
    URL = ""
    URL_ID = ""

    def __init__(self, no):
        self.no = no

    
    @property
    def set_url(self):
        return UserSkill.URL


    @property
    def set_endpoint(self):
        return UserSkill.endpoint


    @set_endpoint.setter
    def set_endpoint(self,userid):
        UserSkill.endpoint="users/"+str(userid)+"/userSkills"


     
    @set_url.setter
    def set_url(self, base_url):
        UserSkill.URL = base_url + UserSkill.endpoint

        
    @property
    def set_url_id(self):
        return UserSkill.URL_ID

        
    @set_url_id.setter
    def set_url_id(self,userskill_id):
        UserSkill.URL_ID = UserSkill.URL + "/" + str(userskill_id)

        
    @property
    def set_query(self):
        return UserSkill.query

        
    @set_query.setter
    def set_query(self, key):
        UserSkill.query["page[offset]"] = str(key["offset"])
        UserSkill.query["page[limit]"] = str(key["limit"])
        if key["sort"]=="dateAchieved":
            UserSkill.query["sort"] = "dateAchieved"
        elif key["sort"]=="-dateAchieved":
            UserSkill.query["sort"] = "-dateAchieved"
        else:
            UserSkill.query["sort"]="dateAchieved"
        try:
            if key["ids"]:
                 UserSkill.query["ids"] = '%2C'.join(key["ids"])
        except Exception as e:
            pass
            if "ids" in UserSkill.query:
                    del UserSkill.query["ids"]
        try:
            if key["include"]:
                 UserSkill.query["include"] = key["include"]
        except Exception as e:
            pass
            if "include" in UserSkill.query:
                 del UserSkill.query["include"]

            
    @property
    def set_header(self):
        return UserSkill.hdr


    @set_header.setter
    def set_header(self, *args):
        token = UserSkill.generate_token()
        UserSkill.hdr["Authorization"] = "oauth " + token["access_token"]

        
    @staticmethod
    def generate_token(base_url):
        global CRED
        global get_New_Token
        print(base_url.split('primeapi')[0])
        url = base_url.split('primeapi')[0]
        access_token = get_New_Token(url,CRED)
        UserSkill.hdr["Authorization"] = "oauth " + access_token["access_token"]

    @classmethod
    def get_userskill_response_body(cls):
        print(UserSkill.URL)
        res = get(UserSkill.URL, params=UserSkill.query, headers=UserSkill.hdr)
        return res.json()


    @classmethod
    def get_userskill_response_code(cls):
        res = get(UserSkill.URL, params=UserSkill.query, headers=UserSkill.hdr)
        return res.status_code


    def pagination_dateachieved(self,reversed,env,userid,pagelimit,offset):
        global enviroment
        fail=False
        test=False
        has_next=True
        total_records_obtained=0


        UserSkill.generate_token(enviroment[env])
        self.set_endpoint=userid
        self.set_url=enviroment[env]

        if not reversed:
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"dateAchieved"}
        else:
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"-dateAchieved"}

        while not fail and has_next:
            try:
                res=UserSkill.get_userskill_response_body()
                total_records_obtained=total_records_obtained+len(res["data"])
                if res["links"]["next"]:
                   print(res["links"]["next"].split('?')[1].split('&')[0])
                   UserSkill.query["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
                   has_next=True
                if len(res["data"])==pagelimit and has_next:
                    if total_records_obtained>self.no:
                        fail=True
                        test=False
                    else:
                        fail=False
                elif len(res["data"])<pagelimit and not has_next:
                    if total_records_obtained<self.no:
                        fail=True
                        test=False
                    elif total_records_obtained==self.no:
                        fail=True
                        test=True
                    elif total_records_obtained>self.no:
                        fail=True
                        test=False
                elif len(res["data"])>pagelimit:
                        fail=True
                        test=False
                elif len(res["data"])<pagelimit and has_next:
                        fail=True
                        test=False
                elif len(res["data"])==pagelimit and not has_next:
                        if total_records_obtained==self.no:
                            test=True
                        else:
                            test=False
                            fail=True
            except KeyError as k:
                 if total_records_obtained==self.no:
                    fail=True
                    test=True
                    has_next=False
                 else:
                    fail=True
                    test=False
                    has_next=False

        return test


if __name__ == "__main__":
    global enviroment
    print(enviroment[sys.argv[1]])
    UserSkill.generate_token(enviroment[sys.argv[1]])
    userskill = UserSkill(34)
    userskill.set_endpoint=sys.argv[2]
    userskill.set_url = enviroment[sys.argv[1]]
    userskill.set_query = {"offset": 0, "limit": 10, "sort": "dateAchieved"}
    print(UserSkill.get_userskill_response_body())
    print(userskill.pagination_dateachieved(False,sys.argv[1],sys.argv[2],2,0))
    print(userskill.pagination_dateachieved(True,sys.argv[1],sys.argv[2],2,0))