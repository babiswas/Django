from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from .forms import CSVForm, SignUpForm
from .models import CSV_File,BoxConfig,BoxToken
from Instructor.utility import *
from django.http import JsonResponse
from boxsdk import Client, OAuth2
from django.contrib import auth

class Constant:
    OAUTH=''


def register(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            if form.save()!=None:
                return redirect('Instructor:login', permanent=True)
            else:
                messages.error(request, 'You are not a valid prime user')
                return render(request, 'Instructor/signup.html', {'form': form, 'message': messages})
        else:
            messages.error(request, 'Invalid Form Error')
            return render(request, 'Instructor/signup.html', {'form': form,'message': messages})
    form = SignUpForm()
    return render(request, 'Instructor/signup.html', {'form': form})


def login(request):
        if request.method == "POST":
            username = request.POST.get('username')
            password = request.POST.get('password')
            res, code = get_user_id(username)
            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)
                return redirect('Instructor:upload', permanent=True)
        return render(request, 'Instructor/login.html')



def logout(request):
    auth.logout(request)
    return redirect('Instructor:login', permanent=True)


def home(request):
    return render(request, 'Instructor/home.html')


def error(request):
    return redirect('Instructor:error', permanent=True)


def upload_csv(request):
    if request.method == "POST":
        form = CSVForm(request.POST, request.FILES)
        if request.FILES['file'].name.split('.')[1] != 'csv' or request.FILES['file'].name!='attendence.csv':
            messages.error(request, 'Invalid File')
            return render(request, 'Instructor/upload.html', {'form': form, 'message': messages})
        if form.is_valid():
            forms=form.save(commit=False)
            forms.email=request.user.email
            forms.save()
            return redirect('Instructor:home')
    form = CSVForm()
    return render(request, 'Instructor/upload.html', {'form': form})


def token_refresh(request):
    try:
        refresh_box_token()
        return JsonResponse({'status':'success'})
    except Exception as e:
        return JsonResponse({'status':'fail'})

def get_box_auth_code(request):
    config=BoxConfig.objects.filter(id=1)
    CLIENT_ID=config[0].client_id
    return redirect('https://account.box.com/api/oauth2/authorize?response_type=code&state=authenticated&client_id='+CLIENT_ID)












