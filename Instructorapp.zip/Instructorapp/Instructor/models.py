from django.db import models
from django.db.models.signals import post_save
from Instructor.utility import get_user_id,refresh_box_token,upload_to_box,get_course_id
from django.shortcuts import redirect
import os
import csv


class BoxConfig(models.Model):
    config_name = models.CharField(max_length=200)
    client_id = models.CharField(max_length=200)
    client_secret = models.CharField(max_length=200)
    email = models.EmailField(null=False, blank=False)
    folderid = models.CharField(max_length=100)
    callback_url = models.URLField(max_length=250)



class BoxToken(models.Model):
    access_token = models.CharField(max_length=100)
    refresh_token = models.CharField(max_length=100)
    email = models.EmailField(null=False, blank=False, default='m@m.com')



class PrimeConfig(models.Model):
    app_name=models.CharField(max_length=100)
    client_id=models.CharField(max_length=100)
    client_secret=models.CharField(max_length=100)
    refresh_token=models.CharField(max_length=100)



class CSV_File(models.Model):
    file_name=models.CharField(max_length=100)
    file=models.FileField(upload_to='test',max_length=254)
    email=models.EmailField()

    def __str__(self):
        return self.file_name




def process_csv(sender,instance,**kwargs):
        path=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+instance.file.url
        file=open(path,'r')
        create_csvs(file,instance.email)
        upload_to_box('Instructor/enrollment.csv','Instructor/user_course_grade.csv')
        file.close()
        return redirect('Instructor:home')

def create_csvs(file,email):
        usergrade = open('Instructor/user_course_grade.csv', 'w',newline='')
        enrollment = open('Instructor/enrollment.csv', 'w',newline='')

        gradecsvwriter = csv.writer(usergrade)
        enrollcsvwriter = csv.writer(enrollment)

        gradecsvwriter.writerow(['userId', 'courseId', 'moduleId', 'completion', 'started', 'success', 'scoreRaw', 'scoreMin', 'scoreMax','startedDate', 'successDate', 'completionDate'])
        enrollcsvwriter.writerow(['userId', 'courseId', 'dateEnrolled', 'deadline', 'assignedByUserId'])
        for line in file.readlines()[1:]:
            moduleid = []
            deadline = []
            element = line.split(',')
            if ' ' in element:
                raise Exception("Missing Values in csv")
            course, code = get_course_id(element[1])
            if code == 200 and len(course["data"]) != 0:
                id = course["data"][0]["id"].split(":")[-1]
                element[1] = id
                for obj in course["included"]:
                    if obj["type"] == "learningObjectInstance":
                        if obj["attributes"]["localizedMetadata"][0]["name"] == element[-1].split('\n')[0]:
                            moduleid.append(obj["relationships"]["loResources"]["data"][0]["id"].split('_')[-2])
                            deadline.append(obj["attributes"]["completionDeadline"])
                enrollment = element[:2] + element[-2:-1] + deadline
                enrollment.append(email)
                usergrade = element[:2] + moduleid + element[2:-2]
                gradecsvwriter.writerow(usergrade)
                enrollcsvwriter.writerow(enrollment)
            else:
                raise Exception("Network Error")
            moduleid[:] = []
            deadline[:] = []

post_save.connect(process_csv,sender=CSV_File)















