from requests import get,post,patch
import json
from boxsdk import Client, OAuth2


TOKEN_URL='https://captivateprimestage1.adobe.com/'
BASE_URL='https://captivateprimestage1.adobe.com/primeapi/v2/'
BOX_URL="https://api.box.com"

data={}

def get_data():
    return data

class Tokens:
    PRIME_ACCESS_TOKEN=''
    BOX_ACCESS_TOKEN=''
    BOX_REFRESH_TOKEN=''

def get_token():
    from Instructor.models import PrimeConfig
    obj=PrimeConfig.objects.filter(id=1)
    cred={"client_id":obj[0].client_id,"client_secret":obj[0].client_secret,"refresh_token":obj[0].refresh_token}
    header = {"Content-type": "application/x-www-form-urlencoded"}
    FINAL_URL=TOKEN_URL+'oauth/token/refresh'
    try:
        response=post(FINAL_URL,params=cred,headers=header)
        DATA=response.json()
        Tokens.PRIME_ACCESS_TOKEN=DATA["access_token"]
        return DATA
    except:
        print("Unable to generate Access Token")

def post_request(func):
    global data
    def wrapper(*args):
        url=BASE_URL+str(args[0])
        Access_Token=get_token()
        hdr={"Authorization":"oauth "+Access_Token["access_token"]}
        res=post(url,params=args[1],headers=hdr)
        return func(args[0],args[1],res.json(),res.status_code)
    return wrapper

def get_request(func):
    global data
    def wrapper(*args):
        url=BASE_URL+str(args[0])
        Access_Token=get_token()
        print(Access_Token)
        hdr={"Authorization":"oauth "+Access_Token["access_token"]}
        res=get(url,params=data,headers=hdr)
        print(res)
        return func(args[0],res.json(),res.status_code)
    return wrapper


@get_request
def get_course(*args):
    return args[1],args[2]

@get_request
def get_user(*args):
    return args[1],args[2]



def get_course_id(id):
    global data
    data.clear()
    data["include"]="instances.loResources.resources"
    data["ids"]="uuid:"+str(id)
    try:
        return get_course("learningObjects")
    except Exception as e:
        return {}



def get_user_id(email):
    global data
    data.clear()
    data["ids"]="email:"+email
    res=get_user("users")
    return res


def refresh_box_token():
    from Instructor.models import BoxConfig
    obj= BoxConfig.objects.filter(id=1)
    ref=BoxToken.objects.filter(id=1)
    payload={"client_id":obj[0].client_id,"client_secret":obj[0].client_secret,"refresh_token":ref[0].refresh_token,"grant_type":"refresh_token"}
    res=post(url, params=args[1], headers=hdr)
    ref[0].refresh_token=res["refresh_token"]
    ref[0].access_token=res["access_token"]
    ref[0].save()


def upload_to_box(*paths):
    from Instructor.models import BoxConfig,BoxToken
    config=BoxConfig.objects.filter(id=1)
    token=BoxToken.objects.filter(id=1)
    CLIENT_ID=config[0].client_id
    CLIRNT_SECRET=config[0].client_secret
    ACCESS_TOKEN=token[0].access_token
    REFRESH_TOKEN=token[0].refresh_token
    FOLDER_ID=config[0].folderid
    oauth = OAuth2(client_id=CLIENT_ID,client_secret=CLIRNT_SECRET,access_token=ACCESS_TOKEN,refresh_token=REFRESH_TOKEN)
    client=Client(oauth)
    for path in paths:
        client.folder(FOLDER_ID).upload(path)























