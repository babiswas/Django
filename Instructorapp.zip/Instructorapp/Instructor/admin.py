from django.contrib import admin
from Instructor.models import *
from django.shortcuts import redirect
from django.contrib import messages
from Instructor.views import error,Constant
from django.urls import path
from django.db import models
from boxsdk import Client, OAuth2


def configure_box(modeladmin,request,queryset):
    try:
      obj=BoxConfig.objects.filter(id=1)
      oauth = OAuth2(client_id=obj[0].client_id, client_secret=obj[0].client_secret)
      Constant.OAUTH=oauth
      return redirect('https://account.box.com/api/oauth2/authorize?response_type=code&state=authenticated&client_id='+obj[0].client_id)
    except Exception as e:
      return redirect('Instructor:error')



class BoxAdmin(admin.ModelAdmin):
    actions=[configure_box]

admin.site.register(BoxConfig,BoxAdmin)
admin.site.register(PrimeConfig)
admin.site.register(BoxToken)


class DummyModel(models.Model):
	class Meta:
		verbose_name_plural = 'Dummy Model'
		app_label = 'Instructor'


def my_custom_view(request):
    code=request.GET.get('code')
    print("Printing code")
    print(code)
    auth_url, csrf_token = Constant.OAUTH.get_authorization_url('http://127.0.0.1:8000/admin/Instructor/dummymodel/settings/')
    access_token, refresh_token = Constant.OAUTH.authenticate(code)
    try:
        token = BoxToken.objects.filter(id=1)
        token[0].access_token = access_token
        token[0].refresh_token = refresh_token
        token[0].save()
    except Exception as e:
        token = BoxToken.objects.create(access_token=access_token, refresh_token=refresh_token)
        token.save()
    return redirect('http://127.0.0.1:8000/admin/Instructor', permanent=True)


class DummyModelAdmin(admin.ModelAdmin):
    model = DummyModel

    def get_urls(self):
        view_name = '{}_{}_changelist'.format(
            self.model._meta.app_label, self.model._meta.model_name)
        return [
            path('settings/', my_custom_view, name=view_name),
        ]

admin.site.register(DummyModel,DummyModelAdmin)