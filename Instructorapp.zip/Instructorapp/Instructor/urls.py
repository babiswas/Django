from django.urls import path,include
from Instructor import views

app_name='Instructor'
urlpatterns = [
   path('signup/',views.register,name='register'),
   path('login/',views.login,name='login'),
   path('logout/',views.logout,name='logout'),
   path('upload/',views.upload_csv,name='upload'),
   path('home/',views.home,name='home'),
   path('error/',views.error,name='error'),
   path('settoken/',views.token_refresh,name='token'),
   path('boxauth/',views.get_box_auth_code,name='authcode')
]