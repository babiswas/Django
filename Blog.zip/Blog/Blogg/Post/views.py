from django.shortcuts import render
from django.views.generic import View
from .models import Post
from django.core.paginator import Paginator
from .forms import Postform
from django.shortcuts import redirect



class PostList(View):
    def get(self,request):
        posts=Post.objects.all()
        paginator=Paginator(posts,2)
        page=request.GET.get('page',None)
        if not page:
           page=1
        posts=paginator.page(page)
        return render(request,'Post/postlist.html',{'posts':posts})

class CreatePost(View):
    def post(self,request):
        form=Postform(request.POST)
        if form.is_valid():
           form=form.save(commit=False)
           form.author=request.user
           form.save()
           return redirect('Post:postlist',permanent=True)
    def get(self,request):
        form=Postform()
        return render(request,'Post/postform.html',{'form':form})









