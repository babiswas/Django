from django.urls import path
from .views import PostList
from.views import CreatePost

app_name='Post'
urlpatterns=[
    path('postlist/',PostList.as_view(),name='postlist'),
    path('createpost/',CreatePost.as_view(),name='createpost')
]