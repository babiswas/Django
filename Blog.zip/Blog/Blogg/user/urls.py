from django.urls import path
from .views import Login,Logout,Sighnup
app_name='user'
urlpatterns=[
    path('sighnup/',Sighnup.as_view(),name='sighnup'),
    path('login/',Login.as_view(),name='login'),
    path('logout/',Logout.as_view(),name='logout')
]