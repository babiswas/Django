from django.shortcuts import render
from django.shortcuts import redirect
from django.contrib import auth
from django.views.generic import View
from .forms import SighnupForm


class Sighnup(View):
    def get(self,request,*args,**kwargs):
        form=SighnupForm()
        return render(request,'user/register.html',{'form':form})

    def post(self,request):
        form=SighnupForm(request.POST)
        print(request.POST)
        print(form)
        if form.is_valid():
            form.save()
            return redirect('user:login')
        return redirect('user:sighnup',permanent=True)

class Login(View):
    def post(self,request):
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('Post:postlist',permanent=True)
    def get(self,request):
        return render(request,'user/login.html')

class Logout(View):
    def get(self,request):
        auth.logout(request)
        return redirect('user:login')


