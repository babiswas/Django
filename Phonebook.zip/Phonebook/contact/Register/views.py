from django.shortcuts import render
from django.contrib import auth
from .forms import SignUpForm
from django.shortcuts import render,redirect

def register(request):
    if request.method=='POST':
        form=SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Register:login',permanent=True)
        else:
            return redirect('Register:signup',permanent=True)
    form=SignUpForm()
    return render(request,'Register/signup.html',{'form':form})

def user_login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('Addcontact:newbook')
    return render(request,'Register/login.html')


def user_logout(request):
    auth.logout(request)
    return redirect('Register:login')
