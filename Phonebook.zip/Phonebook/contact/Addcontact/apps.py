from django.apps import AppConfig


class AddcontactConfig(AppConfig):
    name = 'Addcontact'
