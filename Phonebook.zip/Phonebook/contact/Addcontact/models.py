from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse

CONTACT_TYPE=[('FR','Friend'),('FM','Family'),('WP','Workplace'),('PFR','Professional'),('OTH','Other'),('ER','Emergency')]

class ContactBook(models.Model):
    bookname=models.CharField(max_length=40)
    owner=models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return str(self.bookname)

    def get_absolute_url(self):
        return reverse('Addcontact:bookid',kwargs={"id":self.id})

class Contact(models.Model):
    name=models.CharField(max_length=40,help_text='Enter name')
    phone=models.CharField(max_length=20,help_text='Enter contact no')
    email=models.EmailField(max_length=40)
    adress=models.TextField()
    contacttype=models.CharField(max_length=20,choices=CONTACT_TYPE)
    book=models.ForeignKey(ContactBook,on_delete=models.CASCADE)

    def get_absolute_url(self):
         return reverse('Addcontact:contactdetail',kwargs={"id":self.book.id,"cid":self.id})

