from django import forms
from .models import ContactBook,Contact,CONTACT_TYPE


class ContactBookForm(forms.ModelForm):
    class Meta:
        model=ContactBook
        fields=['bookname',]


class ContactForm(forms.Form):
    name=forms.CharField(max_length=100)
    phone=forms.CharField(max_length=100)
    email=forms.EmailField(max_length=100)
    adress=forms.CharField(widget=forms.Textarea)
    contacttype=forms.CharField(max_length=20,widget=forms.Select(choices=CONTACT_TYPE),)

    def __init__(self,*args,**kwargs):
        instance=None
        try:
          instance=kwargs.pop('instance')
        except KeyError as e:
            instance=None
        super(ContactForm, self).__init__(*args,**kwargs)
        if instance:
            self.fields['name'].initial = instance.name
            self.fields['phone'].initial = instance.phone
            self.fields['email'].initial = instance.email
            self.fields['adress'].initial = instance.adress
            self.fields['contacttype'].initial = instance.contacttype


    def get_object(self):
        data=self.cleaned_data
        contactform=Contact(name=data['name'],phone=data['phone'],email=data['email'],adress=data['adress'],contacttype=data['contacttype'],book=None)
        return contactform

