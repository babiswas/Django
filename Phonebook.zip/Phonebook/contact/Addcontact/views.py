from django.shortcuts import render
from django.shortcuts import redirect
from .forms import ContactBookForm,ContactForm
from .models import ContactBook,Contact
from django.core.paginator import Paginator

def create_book(request):
    if request.method=='POST':
        form=ContactBookForm(request.POST)
        if form.is_valid():
            book=form.save(commit=False)
            book.owner=request.user
            book.save()
            return redirect('Addcontact:booklist')
    form=ContactBookForm()
    return render(request,'Addcontact/contactbook.html',{'form':form})

def book_details(request,id):
    book=ContactBook.objects.get(pk=id)
    contact=Contact.objects.filter(book=book)
    if request.method=='POST':
        form=ContactForm(request.POST)
        if form.is_valid():
           c_form=form.get_object()
           c_form.book=book
           c_form.save()
        return redirect('Addcontact:bookid',id)
    elif request.method=='GET':
        form = ContactForm()
        search=request.GET.get('search',None)
        if (search) and search!='':
            contact=contact.filter(name__icontains=search)
            paginator=Paginator(contact,3)
            page=request.GET.get('page',None)
            if not page:
                page=1
            contact_obj=paginator.page(page)
            return render(request,'Addcontact/contactform.html',{'form':form,'contact_obj':contact_obj,'book':book})
        paginator = Paginator(contact,5)
        print(paginator.count)
        print(paginator.num_pages)
        page=request.GET.get('page',None)
        if not page:
           page=1
        contact_obj=paginator.page(page)
        return render(request,'Addcontact/contactform.html',{'form':form,'contact_obj':contact_obj,'book':book})

def contact_book_list(request):
    book_list=ContactBook.objects.all()
    paginator=Paginator(book_list,4)
    page=request.GET.get('page')
    book_obj=paginator.get_page(page)
    return render(request,'Addcontact/contactbooklist.html',{'book_obj':book_obj})


def contact_detail(request,id,cid):
     contact=Contact.objects.get(pk=cid)
     book=ContactBook.objects.get(pk=id)
     if request.method=='POST':
        form=ContactForm(request.POST or None,instance=contact)
        if form.is_valid():
           contact.name=request.POST['name']
           contact.email=request.POST['email']
           contact.phone=request.POST['phone']
           contact.contacttype=request.POST['contacttype']
           contact.adress=request.POST['adress']
           contact.book=book
           contact.save()
           return redirect('Addcontact:contactdetail',id,cid)
     form=ContactForm(instance=contact)
     return render(request,'Addcontact/contactdetail.html',{'book':book,'form':form,'contact':contact})





