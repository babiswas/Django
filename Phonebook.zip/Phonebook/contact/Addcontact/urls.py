from django.urls import path,include
from .import views

app_name='Addcontact'

urlpatterns=[
    path('contactbook/',views.create_book,name='newbook'),
    path('contactbook/<int:id>/',views.book_details,name='bookid'),
    path('contactbooklist/',views.contact_book_list,name='booklist'),
    path('contactbook/<int:id>/<int:cid>',views.contact_detail,name='contactdetail')
]